--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.2
-- Dumped by pg_dump version 9.6.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

DROP INDEX public.index_users_on_reset_password_token;
DROP INDEX public.index_users_on_email;
ALTER TABLE ONLY public.workouts DROP CONSTRAINT workouts_pkey;
ALTER TABLE ONLY public.workout_plans DROP CONSTRAINT workout_plans_pkey;
ALTER TABLE ONLY public.workout_muscle_groups DROP CONSTRAINT workout_muscle_groups_pkey;
ALTER TABLE ONLY public.workout_exercises DROP CONSTRAINT workout_exercises_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.timers DROP CONSTRAINT timers_pkey;
ALTER TABLE ONLY public.target_muscles DROP CONSTRAINT target_muscles_pkey;
ALTER TABLE ONLY public.schema_migrations DROP CONSTRAINT schema_migrations_pkey;
ALTER TABLE ONLY public.runs DROP CONSTRAINT runs_pkey;
ALTER TABLE ONLY public.plans DROP CONSTRAINT plans_pkey;
ALTER TABLE ONLY public.muscle_groups DROP CONSTRAINT muscle_groups_pkey;
ALTER TABLE ONLY public.exercises DROP CONSTRAINT exercises_pkey;
ALTER TABLE ONLY public.exercise_target_muscles DROP CONSTRAINT exercise_target_muscles_pkey;
ALTER TABLE ONLY public.drills DROP CONSTRAINT drills_pkey;
ALTER TABLE ONLY public.comments DROP CONSTRAINT comments_pkey;
ALTER TABLE ONLY public.ar_internal_metadata DROP CONSTRAINT ar_internal_metadata_pkey;
ALTER TABLE public.workouts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.workout_plans ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.workout_muscle_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.workout_exercises ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.timers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.target_muscles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.runs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.plans ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.muscle_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.exercises ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.exercise_target_muscles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.drills ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.comments ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.workouts_id_seq;
DROP TABLE public.workouts;
DROP SEQUENCE public.workout_plans_id_seq;
DROP TABLE public.workout_plans;
DROP SEQUENCE public.workout_muscle_groups_id_seq;
DROP TABLE public.workout_muscle_groups;
DROP SEQUENCE public.workout_exercises_id_seq;
DROP TABLE public.workout_exercises;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.timers_id_seq;
DROP TABLE public.timers;
DROP SEQUENCE public.target_muscles_id_seq;
DROP TABLE public.target_muscles;
DROP TABLE public.schema_migrations;
DROP SEQUENCE public.runs_id_seq;
DROP TABLE public.runs;
DROP SEQUENCE public.plans_id_seq;
DROP TABLE public.plans;
DROP SEQUENCE public.muscle_groups_id_seq;
DROP TABLE public.muscle_groups;
DROP SEQUENCE public.exercises_id_seq;
DROP TABLE public.exercises;
DROP SEQUENCE public.exercise_target_muscles_id_seq;
DROP TABLE public.exercise_target_muscles;
DROP SEQUENCE public.drills_id_seq;
DROP TABLE public.drills;
DROP SEQUENCE public.comments_id_seq;
DROP TABLE public.comments;
DROP TABLE public.ar_internal_metadata;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE comments (
    id integer NOT NULL,
    user_id integer,
    workout_id integer,
    content character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE comments_id_seq OWNED BY comments.id;


--
-- Name: drills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE drills (
    id integer NOT NULL,
    run_id integer,
    weight integer,
    reps integer,
    rest_period integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    set_number integer,
    exercise_name character varying
);


--
-- Name: drills_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE drills_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: drills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE drills_id_seq OWNED BY drills.id;


--
-- Name: exercise_target_muscles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE exercise_target_muscles (
    id integer NOT NULL,
    exercise_id integer,
    target_muscle_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: exercise_target_muscles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE exercise_target_muscles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: exercise_target_muscles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE exercise_target_muscles_id_seq OWNED BY exercise_target_muscles.id;


--
-- Name: exercises; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE exercises (
    id integer NOT NULL,
    name character varying,
    description character varying,
    reps integer,
    author_id integer,
    rest_period integer,
    equipment_needed character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    weight integer,
    sets integer,
    rating integer
);


--
-- Name: exercises_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE exercises_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: exercises_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE exercises_id_seq OWNED BY exercises.id;


--
-- Name: muscle_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE muscle_groups (
    id integer NOT NULL,
    name character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: muscle_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE muscle_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: muscle_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE muscle_groups_id_seq OWNED BY muscle_groups.id;


--
-- Name: plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE plans (
    id integer NOT NULL,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    description character varying,
    name character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: plans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE plans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE plans_id_seq OWNED BY plans.id;


--
-- Name: runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE runs (
    id integer NOT NULL,
    duration character varying,
    type character varying,
    asets integer,
    areps integer,
    aweight integer,
    arest time without time zone,
    completed_date timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    exercise_id integer,
    user_id integer,
    workout_id integer,
    run_date character varying,
    oneoff_name character varying
);


--
-- Name: runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE runs_id_seq OWNED BY runs.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE schema_migrations (
    version character varying NOT NULL
);


--
-- Name: target_muscles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE target_muscles (
    id integer NOT NULL,
    name character varying,
    muscle_group_id integer,
    run_id integer
);


--
-- Name: target_muscles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE target_muscles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: target_muscles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE target_muscles_id_seq OWNED BY target_muscles.id;


--
-- Name: timers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE timers (
    id integer NOT NULL,
    seconds time without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: timers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE timers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: timers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE timers_id_seq OWNED BY timers.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE users (
    id integer NOT NULL,
    role integer DEFAULT 0,
    username character varying,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    sign_in_count integer DEFAULT 0 NOT NULL,
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    current_sign_in_ip character varying,
    last_sign_in_ip character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    provider character varying,
    uid character varying,
    latitude double precision,
    longtitude double precision
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: workout_exercises; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE workout_exercises (
    id integer NOT NULL,
    exercise_id integer,
    workout_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    combined_rating integer
);


--
-- Name: workout_exercises_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE workout_exercises_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workout_exercises_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE workout_exercises_id_seq OWNED BY workout_exercises.id;


--
-- Name: workout_muscle_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE workout_muscle_groups (
    id integer NOT NULL,
    workout_id integer,
    muscle_group_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: workout_muscle_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE workout_muscle_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workout_muscle_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE workout_muscle_groups_id_seq OWNED BY workout_muscle_groups.id;


--
-- Name: workout_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE workout_plans (
    id integer NOT NULL,
    plan_id integer,
    workout_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: workout_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE workout_plans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workout_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE workout_plans_id_seq OWNED BY workout_plans.id;


--
-- Name: workouts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE workouts (
    id integer NOT NULL,
    name character varying,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    author_id integer
);


--
-- Name: workouts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE workouts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workouts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE workouts_id_seq OWNED BY workouts.id;


--
-- Name: comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY comments ALTER COLUMN id SET DEFAULT nextval('comments_id_seq'::regclass);


--
-- Name: drills id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY drills ALTER COLUMN id SET DEFAULT nextval('drills_id_seq'::regclass);


--
-- Name: exercise_target_muscles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY exercise_target_muscles ALTER COLUMN id SET DEFAULT nextval('exercise_target_muscles_id_seq'::regclass);


--
-- Name: exercises id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY exercises ALTER COLUMN id SET DEFAULT nextval('exercises_id_seq'::regclass);


--
-- Name: muscle_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY muscle_groups ALTER COLUMN id SET DEFAULT nextval('muscle_groups_id_seq'::regclass);


--
-- Name: plans id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY plans ALTER COLUMN id SET DEFAULT nextval('plans_id_seq'::regclass);


--
-- Name: runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY runs ALTER COLUMN id SET DEFAULT nextval('runs_id_seq'::regclass);


--
-- Name: target_muscles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY target_muscles ALTER COLUMN id SET DEFAULT nextval('target_muscles_id_seq'::regclass);


--
-- Name: timers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY timers ALTER COLUMN id SET DEFAULT nextval('timers_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Name: workout_exercises id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY workout_exercises ALTER COLUMN id SET DEFAULT nextval('workout_exercises_id_seq'::regclass);


--
-- Name: workout_muscle_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY workout_muscle_groups ALTER COLUMN id SET DEFAULT nextval('workout_muscle_groups_id_seq'::regclass);


--
-- Name: workout_plans id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY workout_plans ALTER COLUMN id SET DEFAULT nextval('workout_plans_id_seq'::regclass);


--
-- Name: workouts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY workouts ALTER COLUMN id SET DEFAULT nextval('workouts_id_seq'::regclass);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	development	2017-03-15 23:45:45.46915	2017-03-15 23:45:45.46915
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY comments (id, user_id, workout_id, content, created_at, updated_at) FROM stdin;
\.


--
-- Name: comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('comments_id_seq', 1, false);


--
-- Data for Name: drills; Type: TABLE DATA; Schema: public; Owner: -
--

COPY drills (id, run_id, weight, reps, rest_period, created_at, updated_at, set_number, exercise_name) FROM stdin;
97	71	70	12	91	2017-03-24 10:41:26.679666	2017-03-24 10:41:26.679666	1	Dumbell Shoulder Press
98	71	70	10	91	2017-03-24 10:41:26.684303	2017-03-24 10:41:26.684303	2	Dumbell Shoulder Press
99	71	70	8	91	2017-03-24 10:41:26.689853	2017-03-24 10:41:26.689853	3	Dumbell Shoulder Press
100	71	70	7	103	2017-03-24 10:41:26.693061	2017-03-24 10:41:26.693061	4	Dumbell Shoulder Press
101	71	\N	1	91	2017-03-24 10:41:26.697925	2017-03-24 10:41:26.697925	1	handstands
102	71	0	1	76	2017-03-24 10:41:26.701719	2017-03-24 10:41:26.701719	2	handstands
103	71	\N	1	91	2017-03-24 10:41:26.706588	2017-03-24 10:41:26.706588	3	handstands
104	71	\N	\N	61	2017-03-24 10:41:26.709346	2017-03-24 10:41:26.709346	4	handstands
105	72	\N	7	14	2017-03-25 17:24:12.968061	2017-03-25 17:24:12.968061	1	Chinups
106	72	\N	6	91	2017-03-25 17:24:12.974583	2017-03-25 17:24:12.974583	2	Chinups
107	72	\N	4	30	2017-03-25 17:24:12.978409	2017-03-25 17:24:12.978409	3	Chinups
108	72	\N	2	61	2017-03-25 17:24:12.985586	2017-03-25 17:24:12.985586	1	pullups
109	73	150	8	12	2017-03-31 01:14:23.255533	2017-03-31 01:14:23.255533	1	Benchpress
110	73	165	7	12	2017-03-31 01:14:23.257716	2017-03-31 01:14:23.257716	2	Benchpress
111	73	165	8	91	2017-03-31 01:14:23.259728	2017-03-31 01:14:23.259728	3	Benchpress
112	74	0	5	146	2017-04-01 17:37:40.206431	2017-04-01 17:37:40.206431	1	Handstand Pushups
113	74	0	4	123	2017-04-01 17:37:40.215995	2017-04-01 17:37:40.215995	2	Handstand Pushups
114	74	0	3	101	2017-04-01 17:37:40.21954	2017-04-01 17:37:40.21954	3	Handstand Pushups
115	74	0	2	191	2017-04-01 17:37:40.222516	2017-04-01 17:37:40.222516	4	Handstand Pushups
116	75	95	6	91	2017-04-01 17:57:23.848832	2017-04-01 17:57:23.848832	1	Barbell Shoulder Press
117	75	75	8	76	2017-04-01 17:57:23.85664	2017-04-01 17:57:23.85664	2	Barbell Shoulder Press
118	75	75	7	16	2017-04-01 17:57:23.861139	2017-04-01 17:57:23.861139	3	Barbell Shoulder Press
119	76	35	6	91	2017-04-02 00:27:26.055519	2017-04-02 00:27:26.055519	1	Bicep Curls
120	76	35	7	91	2017-04-02 00:27:26.057415	2017-04-02 00:27:26.057415	2	Bicep Curls
121	76	35	7	91	2017-04-02 00:27:26.059169	2017-04-02 00:27:26.059169	3	Bicep Curls
122	76	35	7	3	2017-04-02 00:27:26.061111	2017-04-02 00:27:26.061111	4	Bicep Curls
127	78	\N	29	91	2017-04-04 00:10:05.514917	2017-04-04 00:10:05.514917	1	pushups
128	78	\N	17	91	2017-04-04 00:10:05.519731	2017-04-04 00:10:05.519731	2	pushups
129	78	\N	15	91	2017-04-04 00:10:05.524722	2017-04-04 00:10:05.524722	3	pushups
130	78	\N	13	4	2017-04-04 00:10:05.529141	2017-04-04 00:10:05.529141	4	pushups
137	85	\N	6	91	2017-04-04 10:22:20.869403	2017-04-04 10:22:20.869403	1	chinups
138	85	\N	5	91	2017-04-04 10:22:20.878972	2017-04-04 10:22:20.878972	2	chinups
139	85	\N	5	57	2017-04-04 10:22:20.880672	2017-04-04 10:22:20.880672	3	chinups
140	86	\N	3	16	2017-04-04 10:23:38.333219	2017-04-04 10:23:38.333219	1	chinups
141	87	170	9	91	2017-04-05 21:34:23.826493	2017-04-05 21:34:23.826493	1	Benchpress
142	87	170	8	91	2017-04-05 21:34:23.830586	2017-04-05 21:34:23.830586	2	Benchpress
143	87	165	5	91	2017-04-05 21:34:23.832581	2017-04-05 21:34:23.832581	3	Benchpress
144	87	145	6	157	2017-04-05 21:34:23.834734	2017-04-05 21:34:23.834734	4	Benchpress
145	87	125	4	91	2017-04-05 21:34:23.837189	2017-04-05 21:34:23.837189	1	Incline Press
146	87	125	4	91	2017-04-05 21:34:23.839353	2017-04-05 21:34:23.839353	2	Incline Press
147	87	100	5	2	2017-04-05 21:38:00.08538	2017-04-05 21:38:40.40056	3	Incline Press
148	88	115	10	91	2017-04-06 09:56:43.510325	2017-04-06 09:56:43.510325	1	Barbell Shrugs
149	88	125	8	91	2017-04-06 09:56:43.512272	2017-04-06 09:56:43.512272	2	Barbell Shrugs
150	88	125	7	91	2017-04-06 09:56:43.51414	2017-04-06 09:56:43.51414	3	Barbell Shrugs
151	88	125	6	193	2017-04-06 09:56:43.516059	2017-04-06 09:56:43.516059	4	Barbell Shrugs
153	88	85	8	91	2017-04-06 09:56:43.520026	2017-04-06 09:56:43.520026	2	Tricep Pushdown
154	88	80	8	5	2017-04-06 09:56:43.52219	2017-04-06 09:56:43.52219	3	Tricep Pushdown
152	88	70	11	91	2017-04-06 09:56:43.517851	2017-04-06 09:56:54.438561	1	Tricep Pushdown
155	89	35	8	91	2017-04-07 10:41:43.56436	2017-04-07 10:41:43.56436	1	bicep curl
156	89	35	7	91	2017-04-07 10:41:43.567919	2017-04-07 10:41:43.567919	2	bicep curl
157	89	35	8	91	2017-04-07 10:41:43.571886	2017-04-07 10:41:43.571886	3	bicep curl
158	89	25	8	2	2017-04-07 10:41:43.574935	2017-04-07 10:41:43.574935	4	bicep curl
159	90	0	4	101	2017-04-08 20:48:04.052663	2017-04-08 20:48:04.052663	1	Handstand Pushups
160	90	0	5	146	2017-04-08 20:48:04.055811	2017-04-08 20:48:04.055811	2	Handstand Pushups
161	90	0	3	116	2017-04-08 20:48:04.058145	2017-04-08 20:48:04.058145	3	Handstand Pushups
162	90	0	3	6	2017-04-08 20:48:04.060092	2017-04-08 20:48:04.060092	4	Handstand Pushups
163	91	0	7	111	2017-04-10 23:01:55.973731	2017-04-10 23:01:55.973731	1	pullups
164	91	0	5	111	2017-04-10 23:01:55.978474	2017-04-10 23:01:55.978474	2	pullups
165	91	0	4	111	2017-04-10 23:01:55.982019	2017-04-10 23:01:55.982019	3	pullups
166	91	0	3	35	2017-04-10 23:01:55.988631	2017-04-10 23:01:55.988631	4	pullups
167	91	0	3	76	2017-04-10 23:01:55.994587	2017-04-10 23:01:55.994587	1	chinups
168	91	0	3	1	2017-04-10 23:01:55.999843	2017-04-10 23:01:55.999843	2	chinups
169	92	100	1	61	2017-04-13 01:04:03.166806	2017-04-13 01:04:03.166806	1	Barbell Curls
170	92	85	4	91	2017-04-13 01:04:03.169651	2017-04-13 01:04:03.169651	2	Barbell Curls
171	92	70	8	91	2017-04-13 01:04:03.172228	2017-04-13 01:04:03.172228	3	Barbell Curls
172	92	70	8	169	2017-04-13 01:04:03.175874	2017-04-13 01:04:03.175874	4	Barbell Curls
173	92	15	5	91	2017-04-13 01:04:03.178787	2017-04-13 01:04:03.178787	1	cable curl
174	92	10	8	5	2017-04-13 01:04:03.183469	2017-04-13 01:04:03.183469	2	cable curl
175	93	75	8	91	2017-04-15 17:16:26.475861	2017-04-15 17:16:26.475861	1	Tricep Pushdowns
176	93	75	8	91	2017-04-15 17:16:26.481656	2017-04-15 17:16:26.481656	2	Tricep Pushdowns
177	93	75	7	91	2017-04-15 17:16:26.483593	2017-04-15 17:16:26.483593	3	Tricep Pushdowns
178	93	75	6	4	2017-04-15 17:16:26.485806	2017-04-15 17:16:26.485806	4	Tricep Pushdowns
179	94	165	9	91	2017-04-16 13:26:07.361124	2017-04-16 13:26:07.361124	1	benchpress
180	94	165	8	91	2017-04-16 13:26:07.363575	2017-04-16 13:26:07.363575	2	benchpress
181	94	165	4	91	2017-04-16 13:26:07.365798	2017-04-16 13:26:07.365798	3	benchpress
182	94	165	4	35	2017-04-16 13:26:07.367925	2017-04-16 13:26:07.367925	4	benchpress
183	94	100	8	3	2017-04-16 13:26:07.369987	2017-04-16 13:26:07.369987	1	barbell shrugs
184	94	100	8	2	2017-04-16 13:26:07.372092	2017-04-16 13:26:07.372092	2	barbell shrugs
185	94	100	7	1	2017-04-16 13:26:07.373873	2017-04-16 13:26:07.373873	3	barbell shrugs
186	94	100	6	2	2017-04-16 13:26:07.37593	2017-04-16 13:26:07.37593	4	barbell shrugs
187	95	0	4	116	2017-04-18 09:24:02.592924	2017-04-18 09:24:02.592924	1	Handstand Pushups
188	95	0	3	116	2017-04-18 09:24:02.597817	2017-04-18 09:24:02.597817	2	Handstand Pushups
189	95	0	4	146	2017-04-18 09:24:02.600129	2017-04-18 09:24:02.600129	3	Handstand Pushups
190	95	0	3	146	2017-04-18 09:24:02.601999	2017-04-18 09:24:02.601999	4	Handstand Pushups
191	96	115	5	106	2017-04-19 01:55:38.820858	2017-04-19 01:55:38.820858	1	Barbell Shoulder Press
192	96	95	10	91	2017-04-19 01:55:38.823731	2017-04-19 01:55:38.823731	2	Barbell Shoulder Press
193	96	105	4	106	2017-04-19 01:55:38.825466	2017-04-19 01:55:38.825466	3	Barbell Shoulder Press
194	97	95	5	3	2017-04-19 01:56:52.692678	2017-04-19 01:56:52.692678	1	Barbell Shoulder Press
195	97	0	0	3	2017-04-19 01:56:52.694562	2017-04-19 01:56:52.694562	2	Barbell Shoulder Press
196	97	0	5	2	2017-04-19 01:56:52.696995	2017-04-19 01:56:52.696995	3	Barbell Shoulder Press
197	98	165	9	91	2017-04-19 11:38:54.130488	2017-04-19 11:38:54.130488	1	Squats
198	98	175	9	91	2017-04-19 11:38:54.133067	2017-04-19 11:38:54.133067	2	Squats
199	98	175	7	91	2017-04-19 11:38:54.140342	2017-04-19 11:38:54.140342	3	Squats
200	98	175	7	4	2017-04-19 11:38:54.142368	2017-04-19 11:38:54.142368	4	Squats
201	99	80	8	91	2017-04-19 11:40:25.424933	2017-04-19 11:40:25.424933	1	Bicep Curls
202	99	70	8	91	2017-04-19 11:40:25.427379	2017-04-19 11:40:25.427379	2	Bicep Curls
203	99	70	5	91	2017-04-19 11:40:25.429507	2017-04-19 11:40:25.429507	3	Bicep Curls
204	99	60	6	3	2017-04-19 11:40:25.431736	2017-04-19 11:40:25.431736	4	Bicep Curls
205	100	0	5	91	2017-04-20 09:39:29.355152	2017-04-20 09:39:29.355152	1	chinups
206	100	0	5	91	2017-04-20 09:39:29.359472	2017-04-20 09:39:29.359472	2	chinups
207	100	0	3	121	2017-04-20 09:39:29.363142	2017-04-20 09:39:29.363142	3	chinups
208	100	0	4	196	2017-04-20 09:39:29.36873	2017-04-20 09:39:29.36873	4	chinups
209	101	0	4	111	2017-04-20 09:43:35.503893	2017-04-20 09:43:35.503893	1	pullups
210	101	0	3	4	2017-04-20 09:43:35.507374	2017-04-20 09:43:35.507374	2	pullups
211	102	115	9	91	2017-04-22 23:19:55.238209	2017-04-22 23:19:55.238209	1	Deadlifts with bar
212	102	115	9	91	2017-04-22 23:19:55.241536	2017-04-22 23:19:55.241536	2	Deadlifts with bar
213	102	115	10	91	2017-04-22 23:19:55.243416	2017-04-22 23:19:55.243416	3	Deadlifts with bar
214	102	115	7	46	2017-04-22 23:19:55.245732	2017-04-22 23:19:55.245732	4	Deadlifts with bar
215	102	185	5	91	2017-04-22 23:19:55.248402	2017-04-22 23:19:55.248402	1	benchpress
216	102	170	7	91	2017-04-22 23:19:55.250742	2017-04-22 23:19:55.250742	2	benchpress
217	102	165	3	91	2017-04-22 23:19:55.253211	2017-04-22 23:19:55.253211	3	benchpress
218	102	165	3	24	2017-04-22 23:19:55.255473	2017-04-22 23:19:55.255473	4	benchpress
219	102	80	7	91	2017-04-22 23:19:55.257943	2017-04-22 23:19:55.257943	1	tricep pulldown
220	102	85	7	91	2017-04-22 23:19:55.260313	2017-04-22 23:19:55.260313	2	tricep pulldown
221	102	80	6	91	2017-04-22 23:19:55.262553	2017-04-22 23:19:55.262553	3	tricep pulldown
222	102	80	8	129	2017-04-22 23:19:55.265061	2017-04-22 23:19:55.265061	4	tricep pulldown
223	102	115	10	91	2017-04-22 23:19:55.267187	2017-04-22 23:19:55.267187	1	Shrugs
224	102	115	8	91	2017-04-22 23:19:55.269319	2017-04-22 23:19:55.269319	2	Shrugs
225	102	125	8	91	2017-04-22 23:19:55.271604	2017-04-22 23:19:55.271604	3	Shrugs
226	102	125	7	4	2017-04-22 23:19:55.273561	2017-04-22 23:19:55.273561	4	Shrugs
227	103	0	7	91	2017-04-25 00:26:06.905479	2017-04-25 00:26:06.905479	1	chinups
228	103	0	6	91	2017-04-25 00:26:06.908277	2017-04-25 00:26:06.908277	2	chinups
229	103	0	5	91	2017-04-25 00:26:06.910187	2017-04-25 00:26:06.910187	3	chinups
230	103	0	4	3	2017-04-25 00:26:06.912278	2017-04-25 00:26:06.912278	4	chinups
231	104	70	7	1	2017-04-25 12:57:06.572858	2017-04-25 12:57:06.572858	1	Bicep Curls
232	104	70	6	1	2017-04-25 12:57:06.580326	2017-04-25 12:57:06.580326	2	Bicep Curls
233	104	70	6	2	2017-04-25 12:57:06.59409	2017-04-25 12:57:06.59409	3	Bicep Curls
234	104	70	7	15	2017-04-25 12:57:06.601641	2017-04-25 12:57:06.601641	4	Bicep Curls
235	104	15	7	4	2017-04-25 12:57:06.604499	2017-04-25 12:57:06.604499	1	Cable Curl
236	104	15	7	3	2017-04-25 12:57:06.606672	2017-04-25 12:57:06.606672	2	Cable Curl
237	105	0	5	131	2017-04-28 21:14:05.829142	2017-04-28 21:14:05.829142	1	Handstand Pushups
238	105	0	3	116	2017-04-28 21:14:05.833343	2017-04-28 21:14:05.833343	2	Handstand Pushups
239	105	0	4	116	2017-04-28 21:14:05.835617	2017-04-28 21:14:05.835617	3	Handstand Pushups
240	105	0	4	146	2017-04-28 21:14:05.837603	2017-04-28 21:14:05.837603	4	Handstand Pushups
242	105	95	6	91	2017-04-28 21:14:05.842381	2017-04-28 21:14:05.842381	2	overhead press
243	105	95	4	2	2017-04-28 21:14:05.84551	2017-04-28 21:14:05.84551	3	overhead press
241	105	115	3	91	2017-04-28 21:14:05.840344	2017-04-28 21:14:15.045708	1	overhead press
244	106	95	4	91	2017-04-29 23:13:27.733836	2017-04-29 23:13:27.733836	1	Bicep Curls
245	106	75	7	91	2017-04-29 23:13:27.735834	2017-04-29 23:13:27.735834	2	Bicep Curls
246	106	75	6	91	2017-04-29 23:13:27.738031	2017-04-29 23:13:27.738031	3	Bicep Curls
247	106	75	4	3	2017-04-29 23:13:27.739898	2017-04-29 23:13:27.739898	4	Bicep Curls
248	107	0	7	91	2017-04-29 23:26:44.732034	2017-04-29 23:26:44.732034	1	handing abbs
249	107	0	6	91	2017-04-29 23:26:44.744366	2017-04-29 23:26:44.744366	2	handing abbs
250	107	0	6	91	2017-04-29 23:26:44.747496	2017-04-29 23:26:44.747496	3	handing abbs
251	107	0	5	91	2017-04-29 23:26:44.751278	2017-04-29 23:26:44.751278	4	handing abbs
252	107	0	5	91	2017-04-29 23:26:44.754469	2017-04-29 23:26:44.754469	5	handing abbs
253	107	0	5	91	2017-04-29 23:26:44.757546	2017-04-29 23:26:44.757546	6	handing abbs
254	107	0	5	2	2017-04-29 23:26:44.760329	2017-04-29 23:26:44.760329	7	handing abbs
255	108	0	7	91	2017-05-02 23:26:36.180362	2017-05-02 23:26:36.180362	1	chinups
256	108	0	6	91	2017-05-02 23:26:36.18455	2017-05-02 23:26:36.18455	2	chinups
257	108	0	4	91	2017-05-02 23:26:36.187088	2017-05-02 23:26:36.187088	3	chinups
258	108	0	4	24	2017-05-02 23:26:36.189239	2017-05-02 23:26:36.189239	4	chinups
259	108	0	3	106	2017-05-02 23:26:36.19119	2017-05-02 23:26:36.19119	1	pullups
260	108	0	3	106	2017-05-02 23:26:36.193786	2017-05-02 23:26:36.193786	2	pullups
261	108	0	3	14	2017-05-02 23:26:36.195887	2017-05-02 23:26:36.195887	3	pullups
262	109	95	2	121	2017-05-09 09:26:41.589727	2017-05-09 09:26:41.589727	1	Bicep Curls
263	109	75	7	106	2017-05-09 09:26:41.593575	2017-05-09 09:26:41.593575	2	Bicep Curls
264	109	70	7	91	2017-05-09 09:26:41.598373	2017-05-09 09:26:41.598373	3	Bicep Curls
265	109	70	5	6	2017-05-09 09:26:41.608269	2017-05-09 09:26:41.608269	4	Bicep Curls
266	110	0	3	146	2017-05-09 23:22:03.034453	2017-05-09 23:22:03.034453	1	Handstand Pushups
267	110	0	3	146	2017-05-09 23:22:03.038171	2017-05-09 23:22:03.038171	2	Handstand Pushups
268	110	0	2	146	2017-05-09 23:22:03.040307	2017-05-09 23:22:03.040307	3	Handstand Pushups
269	110	0	3	5	2017-05-09 23:22:03.042889	2017-05-09 23:22:03.042889	4	Handstand Pushups
270	111	0	25	91	2017-05-09 23:25:52.999964	2017-05-09 23:25:52.999964	1	situps
271	111	0	25	91	2017-05-09 23:25:53.003198	2017-05-09 23:25:53.003198	2	situps
272	111	0	25	91	2017-05-09 23:25:53.005963	2017-05-09 23:25:53.005963	3	situps
273	111	\N	25	3	2017-05-09 23:25:53.008319	2017-05-09 23:25:53.008319	4	situps
274	112	80	10	91	2017-05-10 09:28:38.378282	2017-05-10 09:28:38.378282	1	Tricep Pushdown
275	112	80	10	91	2017-05-10 09:28:38.381578	2017-05-10 09:28:38.381578	2	Tricep Pushdown
276	112	80	7	91	2017-05-10 09:28:38.384506	2017-05-10 09:28:38.384506	3	Tricep Pushdown
277	112	80	7	5	2017-05-10 09:28:38.387833	2017-05-10 09:28:38.387833	4	Tricep Pushdown
278	113	0	27	3	2017-05-11 10:34:59.896857	2017-05-11 10:34:59.896857	1	Pushups
279	113	0	15	2	2017-05-11 10:34:59.904319	2017-05-11 10:34:59.904319	2	Pushups
280	113	0	17	46	2017-05-11 10:34:59.907089	2017-05-11 10:34:59.907089	3	Pushups
281	113	0	12	5	2017-05-11 10:34:59.909252	2017-05-11 10:34:59.909252	4	Pushups
282	114	0	4	101	2017-05-17 01:15:41.361493	2017-05-17 01:15:41.361493	1	pullups
283	114	0	4	101	2017-05-17 01:15:41.436851	2017-05-17 01:15:41.436851	2	pullups
284	114	0	4	101	2017-05-17 01:15:41.457668	2017-05-17 01:15:41.457668	3	pullups
285	114	0	4	101	2017-05-17 01:15:41.466846	2017-05-17 01:15:41.466846	4	pullups
286	114	0	4	101	2017-05-17 01:15:41.478906	2017-05-17 01:15:41.478906	5	pullups
287	114	0	4	101	2017-05-17 01:15:41.482573	2017-05-17 01:15:41.482573	6	pullups
288	114	0	4	101	2017-05-17 01:15:41.487426	2017-05-17 01:15:41.487426	7	pullups
289	114	0	4	101	2017-05-17 01:15:41.490359	2017-05-17 01:15:41.490359	8	pullups
290	114	0	4	101	2017-05-17 01:15:41.493533	2017-05-17 01:15:41.493533	9	pullups
291	114	0	4	101	2017-05-17 01:15:41.504015	2017-05-17 01:15:41.504015	10	pullups
292	115	95	10	91	2017-05-17 23:31:59.684813	2017-05-17 23:31:59.684813	1	Shrugs
293	115	125	9	91	2017-05-17 23:31:59.704442	2017-05-17 23:31:59.704442	2	Shrugs
294	115	125	8	91	2017-05-17 23:31:59.707025	2017-05-17 23:31:59.707025	3	Shrugs
295	115	125	7	3	2017-05-17 23:31:59.714679	2017-05-17 23:31:59.714679	4	Shrugs
296	116	95	3	91	2017-05-17 23:32:20.185549	2017-05-17 23:32:20.185549	1	Bicep Curls
297	116	70	8	91	2017-05-17 23:32:20.191552	2017-05-17 23:32:20.191552	2	Bicep Curls
298	116	35	6	91	2017-05-17 23:32:20.193829	2017-05-17 23:32:20.193829	3	Bicep Curls
299	116	75	5	90	2017-05-17 23:32:20.196009	2017-05-17 23:32:20.196009	4	Bicep Curls
300	117	15	10	91	2017-05-17 23:40:56.182648	2017-05-17 23:40:56.182648	1	Higy Cable Curl
301	117	15	8	91	2017-05-17 23:40:56.186392	2017-05-17 23:40:56.186392	2	Higy Cable Curl
302	117	15	8	4	2017-05-17 23:40:56.191101	2017-05-17 23:40:56.191101	3	Higy Cable Curl
303	118	0	15	3	2017-05-18 23:53:21.643766	2017-05-18 23:53:21.643766	1	situps
304	118	0	25	91	2017-05-18 23:53:21.657383	2017-05-18 23:53:21.657383	2	situps
305	118	0	25	91	2017-05-18 23:53:21.660622	2017-05-18 23:53:21.660622	3	situps
306	118	0	20	3	2017-05-18 23:53:21.663458	2017-05-18 23:53:21.663458	4	situps
307	119	0	6	146	2017-05-18 23:57:50.345515	2017-05-18 23:57:50.345515	1	Handstand Pushups
308	119	0	5	116	2017-05-18 23:57:50.347897	2017-05-18 23:57:50.347897	2	Handstand Pushups
309	119	0	5	101	2017-05-18 23:57:50.350616	2017-05-18 23:57:50.350616	3	Handstand Pushups
310	119	0	4	134	2017-05-18 23:57:50.355138	2017-05-18 23:57:50.355138	4	Handstand Pushups
311	119	95	6	91	2017-05-18 23:57:50.357348	2017-05-18 23:57:50.357348	1	shoulder press
312	119	95	5	2	2017-05-18 23:57:50.359283	2017-05-18 23:57:50.359283	2	shoulder press
313	120	195	6	91	2017-05-20 22:21:54.836757	2017-05-20 22:21:54.836757	1	Squats
314	120	165	7	91	2017-05-20 22:21:54.855886	2017-05-20 22:21:54.855886	2	Squats
315	120	165	8	91	2017-05-20 22:21:54.858268	2017-05-20 22:21:54.858268	3	Squats
316	120	165	7	196	2017-05-20 22:21:54.861739	2017-05-20 22:21:54.861739	4	Squats
317	120	115	8	91	2017-05-20 22:21:54.864703	2017-05-20 22:21:54.864703	1	Deadlifts
318	120	115	7	91	2017-05-20 22:21:54.867539	2017-05-20 22:21:54.867539	2	Deadlifts
319	120	115	5	236	2017-05-20 22:21:54.870355	2017-05-20 22:21:54.870355	3	Deadlifts
320	120	195	8	91	2017-05-20 22:21:54.872336	2017-05-20 22:21:54.872336	1	Bench Press
321	120	185	5	91	2017-05-20 22:21:54.880002	2017-05-20 22:21:54.880002	2	Bench Press
322	120	165	7	91	2017-05-20 22:21:54.88284	2017-05-20 22:21:54.88284	3	Bench Press
323	120	151	7	218	2017-05-20 22:21:54.886712	2017-05-20 22:21:54.886712	4	Bench Press
324	120	115	10	91	2017-05-20 22:21:54.888594	2017-05-20 22:21:54.888594	1	Decline press
325	120	125	9	91	2017-05-20 22:21:54.890905	2017-05-20 22:21:54.890905	2	Decline press
326	120	125	8	248	2017-05-20 22:21:54.893902	2017-05-20 22:21:54.893902	3	Decline press
327	120	0	5	121	2017-05-20 22:21:54.896153	2017-05-20 22:21:54.896153	1	pullups
328	120	0	5	121	2017-05-20 22:21:54.898173	2017-05-20 22:21:54.898173	2	pullups
329	120	\N	4	121	2017-05-20 22:21:54.901265	2017-05-20 22:21:54.901265	3	pullups
330	120	0	4	92	2017-05-20 22:21:54.903584	2017-05-20 22:21:54.903584	4	pullups
331	120	79	11	91	2017-05-20 22:21:54.905504	2017-05-20 22:21:54.905504	1	tricep pushdown
332	120	175	10	91	2017-05-20 22:21:54.908933	2017-05-20 22:21:54.908933	2	tricep pushdown
333	120	175	7	91	2017-05-20 22:21:54.912234	2017-05-20 22:21:54.912234	3	tricep pushdown
334	120	70	8	4	2017-05-20 22:21:54.914197	2017-05-20 22:21:54.914197	4	tricep pushdown
335	121	95	4	136	2017-05-24 23:43:34.380967	2017-05-24 23:43:34.380967	1	Barbell Curls
336	121	80	7	91	2017-05-24 23:43:34.394652	2017-05-24 23:43:34.394652	2	Barbell Curls
337	121	80	7	91	2017-05-24 23:43:34.397289	2017-05-24 23:43:34.397289	3	Barbell Curls
338	121	75	6	119	2017-05-24 23:43:34.399763	2017-05-24 23:43:34.399763	4	Barbell Curls
339	121	15	8	91	2017-05-24 23:43:34.402545	2017-05-24 23:43:34.402545	1	high cable curl
340	121	18	8	91	2017-05-24 23:43:34.404613	2017-05-24 23:43:34.404613	2	high cable curl
341	121	15	8	91	2017-05-24 23:43:34.40753	2017-05-24 23:43:34.40753	3	high cable curl
342	121	15	7	4	2017-05-24 23:43:34.409692	2017-05-24 23:43:34.409692	4	high cable curl
343	122	0	7	131	2017-05-27 01:39:10.460548	2017-05-27 01:39:10.460548	1	Handstand Pushups
344	122	0	5	146	2017-05-27 01:39:10.465659	2017-05-27 01:39:10.465659	2	Handstand Pushups
345	122	0	5	146	2017-05-27 01:39:10.468267	2017-05-27 01:39:10.468267	3	Handstand Pushups
346	122	0	5	187	2017-05-27 01:39:10.470239	2017-05-27 01:39:10.470239	4	Handstand Pushups
347	122	70	10	61	2017-05-27 01:39:10.472312	2017-05-27 01:39:10.472312	1	dumbell shoulder press
348	122	70	7	76	2017-05-27 01:39:10.47445	2017-05-27 01:39:10.47445	2	dumbell shoulder press
349	122	70	7	91	2017-05-27 01:39:10.476964	2017-05-27 01:39:10.476964	3	dumbell shoulder press
350	122	70	7	2	2017-05-27 01:39:10.479917	2017-05-27 01:39:10.479917	4	dumbell shoulder press
351	123	165	8	91	2017-05-27 19:28:49.095886	2017-05-27 19:28:49.095886	1	Squats
352	123	165	6	91	2017-05-27 19:28:49.09829	2017-05-27 19:28:49.09829	2	Squats
353	123	135	9	91	2017-05-27 19:28:49.100887	2017-05-27 19:28:49.100887	3	Squats
354	123	135	8	189	2017-05-27 19:28:49.10291	2017-05-27 19:28:49.10291	4	Squats
355	123	135	7	91	2017-05-27 19:28:49.113688	2017-05-27 19:28:49.113688	1	deadlifts
356	123	115	9	91	2017-05-27 19:28:49.117744	2017-05-27 19:28:49.117744	2	deadlifts
357	123	115	7	76	2017-05-27 19:28:49.133963	2017-05-27 19:28:49.133963	3	deadlifts
358	123	165	8	91	2017-05-27 19:28:49.135854	2017-05-27 19:28:49.135854	1	benchpress
360	123	165	7	106	2017-05-27 19:28:49.150228	2017-05-27 19:28:49.150228	3	benchpress
361	123	165	6	89	2017-05-27 19:28:49.153494	2017-05-27 19:28:49.153494	4	benchpress
362	123	115	10	91	2017-05-27 19:28:49.156107	2017-05-27 19:28:49.156107	1	incline benchpress
363	123	115	6	91	2017-05-27 19:28:49.161777	2017-05-27 19:28:49.161777	2	incline benchpress
364	123	115	6	223	2017-05-27 19:28:49.18003	2017-05-27 19:28:49.18003	3	incline benchpress
365	123	0	6	126	2017-05-27 19:28:49.183683	2017-05-27 19:28:49.183683	1	pullups
366	123	0	5	126	2017-05-27 19:28:49.185825	2017-05-27 19:28:49.185825	2	pullups
367	123	0	4	141	2017-05-27 19:28:49.194324	2017-05-27 19:28:49.194324	3	pullups
368	123	0	3	31	2017-05-27 19:28:49.196767	2017-05-27 19:28:49.196767	4	pullups
369	123	115	9	91	2017-05-27 19:28:49.199492	2017-05-27 19:28:49.199492	1	shrugs
370	123	115	9	91	2017-05-27 19:28:49.204089	2017-05-27 19:28:49.204089	2	shrugs
371	123	115	8	91	2017-05-27 19:28:49.218713	2017-05-27 19:28:49.218713	3	shrugs
372	123	115	7	91	2017-05-27 19:28:49.231919	2017-05-27 19:28:49.231919	4	shrugs
359	123	195	3	136	2017-05-27 19:28:49.139445	2017-05-27 19:28:59.222324	2	benchpress
373	125	70	10	90	2017-05-29 20:27:57.268654	2017-05-29 20:28:18.848516	1	Tricep Pushdowns
374	125	80	9	90	2017-05-29 20:27:57.273656	2017-05-29 20:28:18.853789	2	Tricep Pushdowns
375	125	80	10	90	2017-05-29 20:27:57.275538	2017-05-29 20:28:18.85912	3	Tricep Pushdowns
376	125	80	9	90	2017-05-29 20:27:57.277458	2017-05-29 20:28:18.866783	4	Tricep Pushdowns
377	126	0	7	110	2017-05-29 20:29:44.019634	2017-05-29 20:29:57.139164	1	Dips 
378	126	0	8	110	2017-05-29 20:29:44.02223	2017-05-29 20:29:57.143436	2	Dips 
379	126	0	7	110	2017-05-29 20:29:44.024715	2017-05-29 20:29:57.154135	3	Dips 
380	126	0	7	110	2017-05-29 20:29:44.026666	2017-05-29 20:29:57.158093	4	Dips 
381	127	95	4	136	2017-06-01 00:06:23.825593	2017-06-01 00:06:23.825593	1	Bicep Curls
382	127	75	9	91	2017-06-01 00:06:23.860228	2017-06-01 00:06:23.860228	2	Bicep Curls
383	127	75	7	91	2017-06-01 00:06:23.874579	2017-06-01 00:06:23.874579	3	Bicep Curls
384	127	75	5	79	2017-06-01 00:06:23.877316	2017-06-01 00:06:23.877316	4	Bicep Curls
385	127	15	8	91	2017-06-01 00:06:23.879631	2017-06-01 00:06:23.879631	1	high cable curls
386	127	75	10	91	2017-06-01 00:06:23.882636	2017-06-01 00:06:23.882636	2	high cable curls
387	127	75	11	91	2017-06-01 00:06:23.886341	2017-06-01 00:06:23.886341	3	high cable curls
388	127	75	10	81	2017-06-01 00:06:23.889045	2017-06-01 00:06:23.889045	4	high cable curls
389	127	0	4	111	2017-06-01 00:06:23.891995	2017-06-01 00:06:23.891995	1	pullups
390	127	0	4	111	2017-06-01 00:06:23.894127	2017-06-01 00:06:23.894127	2	pullups
391	127	0	3	4	2017-06-01 00:06:23.896398	2017-06-01 00:06:23.896398	3	pullups
399	129	0	5	146	2017-06-03 12:36:01.246691	2017-06-03 12:36:01.246691	1	Handstand Pushups
400	129	0	4	146	2017-06-03 12:36:01.24862	2017-06-03 12:36:01.24862	2	Handstand Pushups
401	129	0	3	146	2017-06-03 12:36:01.250799	2017-06-03 12:36:01.250799	3	Handstand Pushups
402	129	0	3	176	2017-06-03 12:36:01.253347	2017-06-03 12:36:01.253347	4	Handstand Pushups
403	129	115	3	121	2017-06-03 12:36:01.255358	2017-06-03 12:36:01.255358	1	shoulder press
404	129	95	7	91	2017-06-03 12:36:01.257266	2017-06-03 12:36:01.257266	2	shoulder press
405	129	95	5	106	2017-06-03 12:36:01.259854	2017-06-03 12:36:01.259854	3	shoulder press
406	130	100	8	91	2017-06-03 15:19:45.998419	2017-06-03 15:19:45.998419	1	Squats
407	130	45	6	91	2017-06-03 15:19:46.000877	2017-06-03 15:19:46.000877	2	Squats
408	130	80	7	91	2017-06-03 15:19:46.003307	2017-06-03 15:19:46.003307	3	Squats
409	130	70	8	155	2017-06-03 15:19:46.005925	2017-06-03 15:19:46.005925	4	Squats
410	130	90	8	91	2017-06-03 15:19:46.008106	2017-06-03 15:19:46.008106	1	deadlifts
411	130	100	10	91	2017-06-03 15:19:46.011771	2017-06-03 15:19:46.011771	2	deadlifts
412	130	100	12	76	2017-06-03 15:19:46.013894	2017-06-03 15:19:46.013894	3	deadlifts
413	130	100	11	91	2017-06-03 15:19:46.016237	2017-06-03 15:19:46.016237	4	deadlifts
414	131	100	15	61	2017-06-03 15:58:11.815202	2017-06-03 15:58:11.815202	1	Benchpress
415	131	100	11	76	2017-06-03 15:58:11.818485	2017-06-03 15:58:11.818485	2	Benchpress
416	131	100	9	76	2017-06-03 15:58:11.823191	2017-06-03 15:58:11.823191	3	Benchpress
417	131	100	9	92	2017-06-03 15:58:11.829923	2017-06-03 15:58:11.829923	4	Benchpress
418	131	0	12	61	2017-06-03 15:58:11.83745	2017-06-03 15:58:11.83745	1	diamond pushups
419	131	0	6	91	2017-06-03 15:58:11.843495	2017-06-03 15:58:11.843495	2	diamond pushups
420	131	0	8	76	2017-06-03 15:58:11.850205	2017-06-03 15:58:11.850205	3	diamond pushups
421	131	0	8	116	2017-06-03 15:58:11.856026	2017-06-03 15:58:11.856026	4	diamond pushups
422	131	100	8	91	2017-06-03 15:58:11.862402	2017-06-03 15:58:11.862402	1	Barbell incline back
423	131	80	8	91	2017-06-03 15:58:11.865837	2017-06-03 15:58:11.865837	2	Barbell incline back
424	131	80	10	91	2017-06-03 15:58:11.872078	2017-06-03 15:58:11.872078	3	Barbell incline back
425	131	80	8	180	2017-06-03 15:58:11.878437	2017-06-03 15:58:11.878437	4	Barbell incline back
426	131	100	11	91	2017-06-03 15:58:11.886148	2017-06-03 15:58:11.886148	1	shrugs
427	131	100	10	91	2017-06-03 15:58:11.891989	2017-06-03 15:58:11.891989	2	shrugs
428	131	100	15	91	2017-06-03 15:58:11.897644	2017-06-03 15:58:11.897644	3	shrugs
429	132	70	9	91	2017-06-06 10:04:11.348908	2017-06-06 10:04:11.348908	1	Bicep Curls
430	132	70	6	91	2017-06-06 10:04:11.381788	2017-06-06 10:04:11.381788	2	Bicep Curls
431	132	70	6	91	2017-06-06 10:04:11.389329	2017-06-06 10:04:11.389329	3	Bicep Curls
432	132	55	7	118	2017-06-06 10:04:11.396818	2017-06-06 10:04:11.396818	4	Bicep Curls
433	132	15	6	91	2017-06-06 10:04:11.400859	2017-06-06 10:04:11.400859	1	high cable curl
434	132	10	10	91	2017-06-06 10:04:11.405589	2017-06-06 10:04:11.405589	2	high cable curl
435	133	0	7	101	2017-06-07 10:24:44.1306	2017-06-07 10:24:44.1306	1	pullups
436	133	0	4	131	2017-06-07 10:24:44.159462	2017-06-07 10:24:44.159462	2	pullups
437	133	0	5	116	2017-06-07 10:24:44.162121	2017-06-07 10:24:44.162121	3	pullups
438	133	0	4	66	2017-06-07 10:24:44.165243	2017-06-07 10:24:44.165243	4	pullups
439	133	0	0	4	2017-06-07 10:24:44.167982	2017-06-07 10:24:44.167982	5	pullups
440	133	0	0	2	2017-06-07 10:24:44.170862	2017-06-07 10:24:44.170862	6	pullups
441	133	0	0	7	2017-06-07 10:24:44.173031	2017-06-07 10:24:44.173031	7	pullups
442	134	0	5	91	2017-06-07 10:32:10.94486	2017-06-07 10:32:10.94486	1	chinups
443	134	0	3	121	2017-06-07 10:32:10.949025	2017-06-07 10:32:10.949025	2	chinups
444	135	0	5	146	2017-06-14 00:55:43.890452	2017-06-14 00:55:43.890452	1	Handstand Pushups
445	135	0	6	146	2017-06-14 00:55:43.897043	2017-06-14 00:55:43.897043	2	Handstand Pushups
446	135	0	5	146	2017-06-14 00:55:43.899183	2017-06-14 00:55:43.899183	3	Handstand Pushups
447	135	0	4	135	2017-06-14 00:55:43.902375	2017-06-14 00:55:43.902375	4	Handstand Pushups
448	135	115	3	106	2017-06-14 00:55:43.90468	2017-06-14 00:55:43.90468	1	Shoulder Press
449	135	95	7	106	2017-06-14 00:55:43.907183	2017-06-14 00:55:43.907183	2	Shoulder Press
450	135	81	8	91	2017-06-14 00:55:43.910152	2017-06-14 00:55:43.910152	3	Shoulder Press
451	135	81	6	297	2017-06-14 00:55:43.912968	2017-06-14 00:55:43.912968	4	Shoulder Press
452	135	165	5	91	2017-06-14 00:55:43.915336	2017-06-14 00:55:43.915336	1	Bench Press
453	135	165	8	91	2017-06-14 00:55:43.917653	2017-06-14 00:55:43.917653	2	Bench Press
454	135	165	6	91	2017-06-14 00:55:43.920755	2017-06-14 00:55:43.920755	3	Bench Press
455	135	165	5	246	2017-06-14 00:55:43.923167	2017-06-14 00:55:43.923167	4	Bench Press
456	135	115	10	91	2017-06-14 00:55:43.925498	2017-06-14 00:55:43.925498	1	Decline Press
457	135	135	8	91	2017-06-14 00:55:43.927846	2017-06-14 00:55:43.927846	2	Decline Press
458	135	135	8	5	2017-06-14 00:55:43.929558	2017-06-14 00:55:43.929558	3	Decline Press
459	136	75	7	91	2017-06-14 10:33:47.799599	2017-06-14 10:33:47.799599	1	Bicep Curls
460	136	55	10	91	2017-06-14 10:33:47.803669	2017-06-14 10:33:47.803669	2	Bicep Curls
461	136	55	9	91	2017-06-14 10:33:47.806978	2017-06-14 10:33:47.806978	3	Bicep Curls
462	136	61	7	85	2017-06-14 10:33:47.810339	2017-06-14 10:33:47.810339	4	Bicep Curls
463	136	10	9	136	2017-06-14 10:33:47.815104	2017-06-14 10:33:47.815104	1	cable curl
464	136	8	13	91	2017-06-14 10:33:47.820992	2017-06-14 10:33:47.820992	2	cable curl
465	136	8	15	91	2017-06-14 10:33:47.824161	2017-06-14 10:33:47.824161	3	cable curl
466	137	0	6	111	2017-06-15 09:18:55.66487	2017-06-15 09:18:55.66487	1	pullups
467	137	0	5	111	2017-06-15 09:18:55.673827	2017-06-15 09:18:55.673827	2	pullups
468	137	0	5	111	2017-06-15 09:18:55.675846	2017-06-15 09:18:55.675846	3	pullups
469	137	0	4	184	2017-06-15 09:18:55.678018	2017-06-15 09:18:55.678018	4	pullups
472	137	90	10	91	2017-06-15 09:18:55.686013	2017-06-15 09:18:55.686013	3	Lat pulldown
470	137	70	13	91	2017-06-15 09:18:55.680005	2017-06-15 09:19:26.706749	1	Lat pulldown
471	137	90	10	91	2017-06-15 09:18:55.682979	2017-06-15 09:19:26.716077	2	Lat pulldown
473	137	90	9	6	2017-06-15 09:18:55.688894	2017-06-15 09:19:26.730446	4	Lat pulldown
474	138	0	10	61	2017-06-16 09:09:02.724701	2017-06-16 09:09:02.724701	1	dips
475	138	0	10	91	2017-06-16 09:09:02.730349	2017-06-16 09:09:02.730349	2	dips
476	138	0	9	91	2017-06-16 09:09:02.732579	2017-06-16 09:09:02.732579	3	dips
477	139	70	15	91	2017-06-16 09:11:20.664051	2017-06-16 09:11:20.664051	1	Shrugs
478	139	75	12	91	2017-06-16 09:11:20.670149	2017-06-16 09:11:20.670149	2	Shrugs
479	139	90	10	91	2017-06-16 09:11:20.6755	2017-06-16 09:11:20.6755	3	Shrugs
480	140	135	11	91	2017-06-18 00:10:00.27502	2017-06-18 00:10:00.27502	1	Squats
481	140	165	13	91	2017-06-18 00:10:00.280544	2017-06-18 00:10:00.280544	2	Squats
482	140	175	9	91	2017-06-18 00:10:00.283556	2017-06-18 00:10:00.283556	3	Squats
483	140	175	70	259	2017-06-18 00:10:00.285354	2017-06-18 00:10:00.285354	4	Squats
484	140	135	10	91	2017-06-18 00:10:00.287418	2017-06-18 00:10:00.287418	1	Deadlifts
485	140	135	10	91	2017-06-18 00:10:00.289427	2017-06-18 00:10:00.289427	2	Deadlifts
486	140	135	9	223	2017-06-18 00:10:00.291069	2017-06-18 00:10:00.291069	3	Deadlifts
487	140	185	8	106	2017-06-18 00:10:00.293785	2017-06-18 00:10:00.293785	1	Bench Press
488	140	165	10	91	2017-06-18 00:10:00.295773	2017-06-18 00:10:00.295773	2	Bench Press
489	140	155	5	136	2017-06-18 00:10:00.298031	2017-06-18 00:10:00.298031	3	Bench Press
490	140	145	6	271	2017-06-18 00:10:00.300424	2017-06-18 00:10:00.300424	4	Bench Press
491	141	135	4	2	2017-06-18 00:36:04.474224	2017-06-18 00:36:04.474224	1	Incline Press
492	141	115	7	3	2017-06-18 00:36:04.476023	2017-06-18 00:36:04.476023	2	Incline Press
493	141	105	10	13	2017-06-18 00:36:04.478125	2017-06-18 00:36:04.478125	3	Incline Press
494	141	45	10	0	2017-06-18 00:36:04.48343	2017-06-18 00:37:05.722978	1	Tricep Overhead 4 sets
495	142	95	5	166	2017-06-22 22:22:26.869129	2017-06-22 22:22:26.869129	1	Bicep Curls
496	142	75	7	91	2017-06-22 22:22:26.873198	2017-06-22 22:22:26.873198	2	Bicep Curls
497	142	75	8	91	2017-06-22 22:22:26.875885	2017-06-22 22:22:26.875885	3	Bicep Curls
498	142	65	10	241	2017-06-22 22:22:26.879521	2017-06-22 22:22:26.879521	4	Bicep Curls
499	143	10	12	91	2017-06-22 22:30:25.438137	2017-06-22 22:30:25.438137	1	Higy Cable Curl
500	143	10	12	91	2017-06-22 22:30:25.440108	2017-06-22 22:30:25.440108	2	Higy Cable Curl
501	143	10	12	39	2017-06-22 22:30:25.442175	2017-06-22 22:30:25.442175	3	Higy Cable Curl
502	144	75	10	91	2017-06-28 01:41:58.598632	2017-06-28 01:41:58.598632	1	Bicep Curls
503	144	70	8	121	2017-06-28 01:41:58.602252	2017-06-28 01:41:58.602252	2	Bicep Curls
504	144	70	5	106	2017-06-28 01:41:58.60439	2017-06-28 01:41:58.60439	3	Bicep Curls
505	144	60	8	178	2017-06-28 01:41:58.606384	2017-06-28 01:41:58.606384	4	Bicep Curls
506	144	50	9	106	2017-06-28 01:41:58.608549	2017-06-28 01:41:58.608549	1	Plate Hammer Curls
507	144	50	9	91	2017-06-28 01:41:58.610577	2017-06-28 01:41:58.610577	2	Plate Hammer Curls
508	144	50	8	91	2017-06-28 01:41:58.613363	2017-06-28 01:41:58.613363	3	Plate Hammer Curls
509	145	0	6	146	2017-06-28 20:06:31.541207	2017-06-28 20:06:31.541207	1	Handstand Pushups
510	145	0	4	146	2017-06-28 20:06:31.544144	2017-06-28 20:06:31.544144	2	Handstand Pushups
511	145	0	4	146	2017-06-28 20:06:31.545936	2017-06-28 20:06:31.545936	3	Handstand Pushups
512	145	0	6	12	2017-06-28 20:06:31.547959	2017-06-28 20:06:31.547959	4	Handstand Pushups
513	145	95	8	121	2017-06-28 20:06:31.549981	2017-06-28 20:06:31.549981	1	Shoulder Press
514	145	80	10	91	2017-06-28 20:06:31.55197	2017-06-28 20:06:31.55197	2	Shoulder Press
515	145	80	7	91	2017-06-28 20:06:31.554341	2017-06-28 20:06:31.554341	3	Shoulder Press
516	145	75	9	5	2017-06-28 20:06:31.556601	2017-06-28 20:06:31.556601	4	Shoulder Press
517	146	0	8	101	2017-06-30 10:54:14.777877	2017-06-30 10:54:14.777877	1	pullups
518	146	0	5	101	2017-06-30 10:54:14.781892	2017-06-30 10:54:14.781892	2	pullups
519	146	0	5	101	2017-06-30 10:54:14.78377	2017-06-30 10:54:14.78377	3	pullups
520	146	0	4	5	2017-06-30 10:54:14.78611	2017-06-30 10:54:14.78611	4	pullups
521	147	0	5	91	2017-06-30 11:04:08.043019	2017-06-30 11:04:08.043019	1	Chinups
522	147	0	4	91	2017-06-30 11:04:08.046646	2017-06-30 11:04:08.046646	2	Chinups
523	148	95	7	101	2017-07-01 19:53:04.941744	2017-07-01 19:53:04.941744	1	Forward Lunges Barbell
524	148	95	8	101	2017-07-01 19:53:04.965741	2017-07-01 19:53:04.965741	2	Forward Lunges Barbell
525	148	95	6	101	2017-07-01 19:53:04.968526	2017-07-01 19:53:04.968526	3	Forward Lunges Barbell
526	148	95	7	263	2017-07-01 19:53:04.970628	2017-07-01 19:53:04.970628	4	Forward Lunges Barbell
527	148	115	8	101	2017-07-01 19:53:04.972589	2017-07-01 19:53:04.972589	1	Deadlifts
528	148	115	10	101	2017-07-01 19:53:04.974942	2017-07-01 19:53:04.974942	2	Deadlifts
529	148	125	9	94	2017-07-01 19:53:04.97815	2017-07-01 19:53:04.97815	3	Deadlifts
530	148	175	10	101	2017-07-01 19:53:04.981732	2017-07-01 19:53:04.981732	1	Bench Press
531	148	165	8	101	2017-07-01 19:53:04.98571	2017-07-01 19:53:04.98571	2	Bench Press
532	148	165	6	101	2017-07-01 19:53:04.988635	2017-07-01 19:53:04.988635	3	Bench Press
533	148	140	5	272	2017-07-01 19:53:04.992574	2017-07-01 19:53:04.992574	4	Bench Press
534	148	115	8	121	2017-07-01 19:53:05.002653	2017-07-01 19:53:05.002653	1	Incline Press
535	148	105	10	91	2017-07-01 19:53:05.005511	2017-07-01 19:53:05.005511	2	Incline Press
536	148	115	9	6	2017-07-01 19:53:05.008386	2017-07-01 19:53:05.008386	3	Incline Press
537	148	\N	\N	283	2017-07-01 19:53:05.01947	2017-07-01 19:53:05.01947	4	Incline Press
538	148	0	9	111	2017-07-01 19:53:05.023918	2017-07-01 19:53:05.023918	1	Dips
539	148	0	6	111	2017-07-01 19:53:05.029506	2017-07-01 19:53:05.029506	2	Dips
540	148	0	7	111	2017-07-01 19:53:05.033951	2017-07-01 19:53:05.033951	3	Dips
541	148	0	7	25	2017-07-01 19:53:05.043934	2017-07-01 19:53:05.043934	4	Dips
542	148	25	10	2	2017-07-01 19:53:05.047719	2017-07-01 19:53:05.047719	1	situps
543	148	25	10	1	2017-07-01 19:53:05.052492	2017-07-01 19:53:05.052492	2	situps
544	148	25	10	1	2017-07-01 19:53:05.057289	2017-07-01 19:53:05.057289	3	situps
545	148	25	10	2	2017-07-01 19:53:05.060541	2017-07-01 19:53:05.060541	4	situps
546	149	70	10	91	2017-07-03 21:38:04.575666	2017-07-03 21:38:04.575666	1	Bicep Curls
547	149	70	7	91	2017-07-03 21:38:04.603912	2017-07-03 21:38:04.603912	2	Bicep Curls
548	149	65	8	91	2017-07-03 21:38:04.607805	2017-07-03 21:38:04.607805	3	Bicep Curls
549	149	65	7	56	2017-07-03 21:38:04.61197	2017-07-03 21:38:04.61197	4	Bicep Curls
550	149	10	9	91	2017-07-03 21:38:04.616655	2017-07-03 21:38:04.616655	1	High Cable Curl
551	149	10	10	91	2017-07-03 21:38:04.6202	2017-07-03 21:38:04.6202	2	High Cable Curl
552	149	10	8	3	2017-07-03 21:38:04.62371	2017-07-03 21:38:04.62371	3	High Cable Curl
553	150	0	8	146	2017-07-06 08:56:54.029639	2017-07-06 08:56:54.029639	1	Handstand Pushups
554	150	0	5	146	2017-07-06 08:56:54.039332	2017-07-06 08:56:54.039332	2	Handstand Pushups
555	150	0	3	146	2017-07-06 08:56:54.041489	2017-07-06 08:56:54.041489	3	Handstand Pushups
556	150	0	4	17	2017-07-06 08:56:54.054104	2017-07-06 08:56:54.054104	4	Handstand Pushups
557	150	95	6	121	2017-07-06 08:56:54.063141	2017-07-06 08:56:54.063141	1	shoulder press
558	150	80	8	91	2017-07-06 08:56:54.06645	2017-07-06 08:56:54.06645	2	shoulder press
559	150	80	8	3	2017-07-06 08:56:54.074691	2017-07-06 08:56:54.074691	3	shoulder press
560	151	\N	6	101	2017-07-07 08:47:12.203502	2017-07-07 08:47:12.203502	1	pullups
561	151	0	5	101	2017-07-07 08:47:12.206614	2017-07-07 08:47:12.206614	2	pullups
562	151	0	5	101	2017-07-07 08:47:12.208785	2017-07-07 08:47:12.208785	3	pullups
563	151	0	4	4	2017-07-07 08:47:12.210963	2017-07-07 08:47:12.210963	4	pullups
564	152	0	4	91	2017-07-07 08:55:13.730408	2017-07-07 08:55:13.730408	1	Chinups
565	152	0	4	91	2017-07-07 08:55:13.732422	2017-07-07 08:55:13.732422	2	Chinups
566	152	0	3	8	2017-07-07 08:55:13.734116	2017-07-07 08:55:13.734116	3	Chinups
567	153	70	13	61	2017-07-07 09:02:18.393425	2017-07-07 09:02:18.393425	1	Barbell Shrugs
568	153	70	8	61	2017-07-07 09:02:18.395959	2017-07-07 09:02:18.395959	2	Barbell Shrugs
569	153	70	9	3	2017-07-07 09:02:18.397925	2017-07-07 09:02:18.397925	3	Barbell Shrugs
570	154	135	10	91	2017-07-08 14:25:56.796963	2017-07-08 14:25:56.796963	1	Squats
571	154	165	10	91	2017-07-08 14:25:56.803118	2017-07-08 14:25:56.803118	2	Squats
572	154	175	6	91	2017-07-08 14:25:56.805726	2017-07-08 14:25:56.805726	3	Squats
573	154	145	10	229	2017-07-08 14:25:56.80827	2017-07-08 14:25:56.80827	4	Squats
574	154	115	12	91	2017-07-08 14:25:56.810818	2017-07-08 14:25:56.810818	1	Deadlifts
575	154	135	9	91	2017-07-08 14:25:56.813576	2017-07-08 14:25:56.813576	2	Deadlifts
576	154	135	8	91	2017-07-08 14:25:56.815904	2017-07-08 14:25:56.815904	3	Deadlifts
577	154	135	10	404	2017-07-08 14:25:56.818277	2017-07-08 14:25:56.818277	4	Deadlifts
578	154	185	9	91	2017-07-08 14:25:56.820264	2017-07-08 14:25:56.820264	1	Bench Press
579	154	165	9	91	2017-07-08 14:25:56.822244	2017-07-08 14:25:56.822244	2	Bench Press
580	154	150	5	121	2017-07-08 14:25:56.824141	2017-07-08 14:25:56.824141	3	Bench Press
581	154	135	6	249	2017-07-08 14:25:56.826055	2017-07-08 14:25:56.826055	4	Bench Press
582	154	115	11	91	2017-07-08 14:25:56.828148	2017-07-08 14:25:56.828148	1	Decline Press
583	154	125	7	91	2017-07-08 14:25:56.82993	2017-07-08 14:25:56.82993	2	Decline Press
584	154	120	8	91	2017-07-08 14:25:56.831891	2017-07-08 14:25:56.831891	3	Decline Press
585	154	125	9	91	2017-07-08 14:25:56.833898	2017-07-08 14:25:56.833898	4	Decline Press
586	155	70	8	91	2017-07-08 14:50:20.565859	2017-07-08 14:50:20.565859	1	Bicep Curls
587	155	65	8	91	2017-07-08 14:50:20.5688	2017-07-08 14:50:20.5688	2	Bicep Curls
588	155	65	8	91	2017-07-08 14:50:20.57477	2017-07-08 14:50:20.57477	3	Bicep Curls
589	155	55	9	199	2017-07-08 14:50:20.580293	2017-07-08 14:50:20.580293	4	Bicep Curls
590	155	0	11	0	2017-07-08 14:50:20.583251	2017-07-08 14:50:20.583251	1	Dips
591	155	0	8	80	2017-07-08 14:50:20.585551	2017-07-08 14:50:20.585551	2	Dips
592	155	0	5	252	2017-07-08 14:50:20.593892	2017-07-08 14:50:20.593892	3	Dips
593	155	0	7	18	2017-07-08 14:50:20.600385	2017-07-08 14:50:20.600385	4	Dips
594	155	0	25	1	2017-07-08 14:50:20.607112	2017-07-08 14:50:20.607112	1	situps
595	155	0	25	1	2017-07-08 14:50:20.613837	2017-07-08 14:50:20.613837	2	situps
596	155	0	25	1	2017-07-08 14:50:20.622083	2017-07-08 14:50:20.622083	3	situps
597	155	0	25	2	2017-07-08 14:50:20.626758	2017-07-08 14:50:20.626758	4	situps
598	156	0	6	101	2017-07-10 08:52:20.599104	2017-07-10 08:52:20.599104	1	pullups
599	156	0	5	101	2017-07-10 08:52:20.601161	2017-07-10 08:52:20.601161	2	pullups
600	156	0	4	101	2017-07-10 08:52:20.603024	2017-07-10 08:52:20.603024	3	pullups
601	156	0	4	101	2017-07-10 08:52:20.605294	2017-07-10 08:52:20.605294	4	pullups
602	157	70	10	91	2017-07-10 08:59:02.432243	2017-07-10 08:59:02.432243	1	Lat Pulldown
603	157	90	8	91	2017-07-10 08:59:02.435224	2017-07-10 08:59:02.435224	2	Lat Pulldown
604	157	70	9	20	2017-07-10 08:59:02.437576	2017-07-10 08:59:02.437576	3	Lat Pulldown
605	157	70	6	2	2017-07-10 08:59:02.439418	2017-07-10 08:59:02.439418	1	Shrugs
606	157	70	6	2	2017-07-10 08:59:02.441473	2017-07-10 08:59:02.441473	2	Shrugs
607	158	65	8	130	2017-07-12 00:25:05.695696	2017-07-12 00:25:22.012304	1	Bicep Curls
608	158	65	8	130	2017-07-12 00:25:05.70416	2017-07-12 00:25:22.016989	2	Bicep Curls
609	158	55	7	130	2017-07-12 00:25:05.70719	2017-07-12 00:25:22.020582	3	Bicep Curls
610	158	55	7	130	2017-07-12 00:25:05.709125	2017-07-12 00:25:22.027062	4	Bicep Curls
611	158	50	8	130	2017-07-12 00:25:05.710982	2017-07-12 00:25:22.033748	1	Hammer Curls with Plates
612	158	50	7	130	2017-07-12 00:25:05.712757	2017-07-12 00:25:22.040711	2	Hammer Curls with Plates
613	158	50	7	130	2017-07-12 00:25:05.714503	2017-07-12 00:25:22.046438	3	Hammer Curls with Plates
614	159	0	5	146	2017-07-12 08:58:33.337103	2017-07-12 08:58:33.337103	1	Handstand Pushups
615	159	0	6	146	2017-07-12 08:58:33.352312	2017-07-12 08:58:33.352312	2	Handstand Pushups
616	159	0	5	146	2017-07-12 08:58:33.355051	2017-07-12 08:58:33.355051	3	Handstand Pushups
617	159	0	4	134	2017-07-12 08:58:33.357735	2017-07-12 08:58:33.357735	4	Handstand Pushups
618	159	95	6	106	2017-07-12 08:58:33.36081	2017-07-12 08:58:33.36081	1	Shoulder Press
619	159	75	9	106	2017-07-12 08:58:33.364422	2017-07-12 08:58:33.364422	2	Shoulder Press
620	159	75	8	91	2017-07-12 08:58:33.37627	2017-07-12 08:58:33.37627	3	Shoulder Press
621	160	70	15	76	2017-07-13 09:19:35.678762	2017-07-13 09:19:35.678762	1	Tricep Pushdown
622	160	90	8	91	2017-07-13 09:19:35.687399	2017-07-13 09:19:35.687399	2	Tricep Pushdown
623	160	80	9	91	2017-07-13 09:19:35.689417	2017-07-13 09:19:35.689417	3	Tricep Pushdown
624	160	80	9	151	2017-07-13 09:19:35.691563	2017-07-13 09:19:35.691563	4	Tricep Pushdown
625	161	0	12	61	2017-07-13 09:29:27.582631	2017-07-13 09:29:27.582631	1	Dimond pushups
626	161	0	10	91	2017-07-13 09:29:27.584626	2017-07-13 09:29:27.584626	2	Dimond pushups
627	161	0	12	61	2017-07-13 09:29:27.586725	2017-07-13 09:29:27.586725	3	Dimond pushups
628	161	0	9	5	2017-07-13 09:29:27.589114	2017-07-13 09:29:27.589114	4	Dimond pushups
629	162	0	4	86	2017-07-14 09:22:53.480492	2017-07-14 09:22:53.480492	1	pullups
630	162	0	6	101	2017-07-14 09:22:53.488495	2017-07-14 09:22:53.488495	2	pullups
631	162	0	5	101	2017-07-14 09:22:53.490498	2017-07-14 09:22:53.490498	3	pullups
632	162	0	4	191	2017-07-14 09:22:53.492526	2017-07-14 09:22:53.492526	4	pullups
633	163	0	6	91	2017-07-14 09:33:01.387384	2017-07-14 09:33:01.387384	1	chinups
634	163	0	5	91	2017-07-14 09:33:01.389366	2017-07-14 09:33:01.389366	2	chinups
635	163	0	5	2	2017-07-14 09:33:01.391457	2017-07-14 09:33:01.391457	3	chinups
636	164	115	8	101	2017-07-15 15:21:55.383455	2017-07-15 15:21:55.383455	1	Forward Lunges Barbell
637	164	95	8	101	2017-07-15 15:21:55.385775	2017-07-15 15:21:55.385775	2	Forward Lunges Barbell
638	164	95	8	101	2017-07-15 15:21:55.388221	2017-07-15 15:21:55.388221	3	Forward Lunges Barbell
639	164	95	8	212	2017-07-15 15:21:55.390453	2017-07-15 15:21:55.390453	4	Forward Lunges Barbell
640	164	115	12	91	2017-07-15 15:21:55.392837	2017-07-15 15:21:55.392837	1	Deadlifts
641	164	135	10	91	2017-07-15 15:21:55.394941	2017-07-15 15:21:55.394941	2	Deadlifts
642	164	145	8	91	2017-07-15 15:21:55.397254	2017-07-15 15:21:55.397254	3	Deadlifts
643	164	135	8	214	2017-07-15 15:21:55.40009	2017-07-15 15:21:55.40009	4	Deadlifts
644	164	185	10	91	2017-07-15 15:21:55.402295	2017-07-15 15:21:55.402295	1	Bench Press
645	164	165	8	106	2017-07-15 15:21:55.404772	2017-07-15 15:21:55.404772	2	Bench Press
646	164	145	8	91	2017-07-15 15:21:55.407247	2017-07-15 15:21:55.407247	3	Bench Press
647	164	135	7	271	2017-07-15 15:21:55.409745	2017-07-15 15:21:55.409745	4	Bench Press
648	164	135	5	91	2017-07-15 15:21:55.412281	2017-07-15 15:21:55.412281	1	Incline Press
649	164	115	8	91	2017-07-15 15:21:55.419862	2017-07-15 15:21:55.419862	2	Incline Press
650	164	100	8	91	2017-07-15 15:21:55.423358	2017-07-15 15:21:55.423358	3	Incline Press
651	164	100	7	218	2017-07-15 15:21:55.425805	2017-07-15 15:21:55.425805	4	Incline Press
652	164	0	8	91	2017-07-15 15:21:55.428712	2017-07-15 15:21:55.428712	1	Dips
653	164	0	9	91	2017-07-15 15:21:55.431207	2017-07-15 15:21:55.431207	2	Dips
654	164	0	7	91	2017-07-15 15:21:55.434486	2017-07-15 15:21:55.434486	3	Dips
655	165	\N	6	146	2017-07-17 08:55:43.9997	2017-07-17 08:55:43.9997	1	Handstand Pushups
656	165	0	6	146	2017-07-17 08:55:44.007551	2017-07-17 08:55:44.007551	2	Handstand Pushups
657	165	0	5	146	2017-07-17 08:55:44.009656	2017-07-17 08:55:44.009656	3	Handstand Pushups
658	165	0	6	191	2017-07-17 08:55:44.011822	2017-07-17 08:55:44.011822	4	Handstand Pushups
659	166	95	6	91	2017-07-17 09:04:31.358963	2017-07-17 09:04:31.358963	1	Barbell Shoulder Press
660	166	75	8	91	2017-07-17 09:04:31.361873	2017-07-17 09:04:31.361873	2	Barbell Shoulder Press
661	166	80	8	91	2017-07-17 09:04:31.363862	2017-07-17 09:04:31.363862	3	Barbell Shoulder Press
662	167	80	6	4	2017-07-18 09:02:50.793525	2017-07-18 09:02:50.793525	1	Bicep Curls
663	167	70	9	1	2017-07-18 09:02:50.802898	2017-07-18 09:02:50.802898	2	Bicep Curls
664	167	70	8	8	2017-07-18 09:02:50.805119	2017-07-18 09:02:50.805119	3	Bicep Curls
665	167	65	8	198	2017-07-18 09:02:50.806923	2017-07-18 09:02:50.806923	4	Bicep Curls
666	167	10	11	91	2017-07-18 09:02:50.808632	2017-07-18 09:02:50.808632	1	High Cable Curl
667	167	12	7	91	2017-07-18 09:02:50.810712	2017-07-18 09:02:50.810712	2	High Cable Curl
668	168	0	7	41	2017-07-19 08:50:48.722626	2017-07-19 08:50:48.722626	1	pullups
669	168	0	5	101	2017-07-19 08:50:48.726233	2017-07-19 08:50:48.726233	2	pullups
670	168	0	6	101	2017-07-19 08:50:48.728235	2017-07-19 08:50:48.728235	3	pullups
671	168	0	4	69	2017-07-19 08:50:48.730158	2017-07-19 08:50:48.730158	4	pullups
672	169	70	11	91	2017-07-19 09:03:35.86382	2017-07-19 09:03:35.86382	1	Lat Pulldown
673	169	11	90	91	2017-07-19 09:03:35.865735	2017-07-19 09:03:35.865735	2	Lat Pulldown
674	169	90	11	18	2017-07-19 09:03:35.867502	2017-07-19 09:03:35.867502	3	Lat Pulldown
675	169	115	10	2	2017-07-19 09:03:35.869414	2017-07-19 09:03:35.869414	1	SHrugs
676	169	115	9	41	2017-07-19 09:03:35.871502	2017-07-19 09:03:35.871502	2	SHrugs
677	169	115	8	3	2017-07-19 09:03:35.873558	2017-07-19 09:03:35.873558	3	SHrugs
678	170	80	11	31	2017-07-20 09:54:47.829989	2017-07-20 09:54:47.829989	1	Tricep Pushdown
679	170	90	11	91	2017-07-20 09:54:47.832163	2017-07-20 09:54:47.832163	2	Tricep Pushdown
680	170	90	10	91	2017-07-20 09:54:47.834062	2017-07-20 09:54:47.834062	3	Tricep Pushdown
681	170	80	7	171	2017-07-20 09:54:47.835935	2017-07-20 09:54:47.835935	4	Tricep Pushdown
682	170	0	13	91	2017-07-20 09:54:47.83796	2017-07-20 09:54:47.83796	1	tricep pushups
683	170	0	15	91	2017-07-20 09:54:47.839832	2017-07-20 09:54:47.839832	2	tricep pushups
684	171	165	8	91	2017-07-22 15:03:58.938009	2017-07-22 15:03:58.938009	1	Squats
685	171	165	9	91	2017-07-22 15:03:58.942042	2017-07-22 15:03:58.942042	2	Squats
686	171	8	165	91	2017-07-22 15:03:58.945503	2017-07-22 15:03:58.945503	3	Squats
687	171	165	9	226	2017-07-22 15:03:58.947691	2017-07-22 15:03:58.947691	4	Squats
688	172	115	13	91	2017-07-22 15:16:37.540291	2017-07-22 15:16:37.540291	1	Deadlifts with bar
689	172	135	8	91	2017-07-22 15:16:37.543075	2017-07-22 15:16:37.543075	2	Deadlifts with bar
690	172	135	8	91	2017-07-22 15:16:37.545352	2017-07-22 15:16:37.545352	3	Deadlifts with bar
691	172	135	9	226	2017-07-22 15:16:37.553639	2017-07-22 15:16:37.553639	4	Deadlifts with bar
692	173	185	8	91	2017-07-22 15:29:49.66778	2017-07-22 15:29:49.66778	1	Benchpress
693	173	165	9	106	2017-07-22 15:29:49.671001	2017-07-22 15:29:49.671001	2	Benchpress
694	173	145	6	91	2017-07-22 15:29:49.673113	2017-07-22 15:29:49.673113	3	Benchpress
695	173	145	5	226	2017-07-22 15:29:49.675017	2017-07-22 15:29:49.675017	4	Benchpress
696	174	0	10	2	2017-07-22 18:00:13.142368	2017-07-22 18:00:13.142368	1	dips
697	174	0	7	2	2017-07-22 18:00:13.155479	2017-07-22 18:00:13.155479	2	dips
698	174	0	5	1	2017-07-22 18:00:13.157612	2017-07-22 18:00:13.157612	3	dips
699	174	0	5	18	2017-07-22 18:00:13.159737	2017-07-22 18:00:13.159737	4	dips
700	174	125	13	4	2017-07-22 18:00:13.16158	2017-07-22 18:00:13.16158	1	decline press
701	174	145	8	1	2017-07-22 18:00:13.163608	2017-07-22 18:00:13.163608	2	decline press
702	174	125	8	2	2017-07-22 18:00:13.165388	2017-07-22 18:00:13.165388	3	decline press
703	175	0	8	146	2017-07-24 09:02:55.998601	2017-07-24 09:02:55.998601	1	Handstand Pushups
704	175	0	5	146	2017-07-24 09:02:56.002182	2017-07-24 09:02:56.002182	2	Handstand Pushups
705	175	0	5	146	2017-07-24 09:02:56.004036	2017-07-24 09:02:56.004036	3	Handstand Pushups
706	175	0	5	175	2017-07-24 09:02:56.005803	2017-07-24 09:02:56.005803	4	Handstand Pushups
707	175	95	7	91	2017-07-24 09:02:56.007494	2017-07-24 09:02:56.007494	1	Shoulder Press
708	175	75	8	91	2017-07-24 09:02:56.009199	2017-07-24 09:02:56.009199	2	Shoulder Press
709	176	75	8	91	2017-07-26 09:00:43.201418	2017-07-26 09:00:43.201418	1	Bicep Curls
710	176	75	8	91	2017-07-26 09:00:43.205919	2017-07-26 09:00:43.205919	2	Bicep Curls
711	176	75	8	91	2017-07-26 09:00:43.209373	2017-07-26 09:00:43.209373	3	Bicep Curls
712	176	65	10	196	2017-07-26 09:00:43.212137	2017-07-26 09:00:43.212137	4	Bicep Curls
713	177	15	9	91	2017-07-26 09:10:43.529952	2017-07-26 09:10:43.529952	1	Higy Cable Curl
714	177	15	8	91	2017-07-26 09:10:43.532227	2017-07-26 09:10:43.532227	2	Higy Cable Curl
715	177	15	8	91	2017-07-26 09:10:43.533974	2017-07-26 09:10:43.533974	3	Higy Cable Curl
716	178	0	6	101	2017-07-28 08:46:20.777223	2017-07-28 08:46:20.777223	1	pullups
717	178	0	5	131	2017-07-28 08:46:20.791712	2017-07-28 08:46:20.791712	2	pullups
718	178	0	4	101	2017-07-28 08:46:20.79416	2017-07-28 08:46:20.79416	3	pullups
719	179	0	5	4	2017-07-28 08:46:39.451673	2017-07-28 08:46:39.451673	1	pullups
720	180	80	12	91	2017-07-28 09:00:40.010668	2017-07-28 09:00:40.010668	1	Lat Pulldown
721	180	80	10	91	2017-07-28 09:00:40.01327	2017-07-28 09:00:40.01327	2	Lat Pulldown
722	180	90	11	36	2017-07-28 09:00:40.016312	2017-07-28 09:00:40.016312	3	Lat Pulldown
723	180	90	10	3	2017-07-28 09:00:40.018557	2017-07-28 09:00:40.018557	1	lat pull down
724	181	135	12	2	2017-07-29 16:17:34.264373	2017-07-29 16:17:34.264373	1	Squats
725	181	175	8	2	2017-07-29 16:17:34.280597	2017-07-29 16:17:34.280597	2	Squats
726	181	175	8	2	2017-07-29 16:17:34.284697	2017-07-29 16:17:34.284697	3	Squats
727	181	175	9	14	2017-07-29 16:17:34.290406	2017-07-29 16:17:34.290406	4	Squats
728	181	135	12	91	2017-07-29 16:17:34.292957	2017-07-29 16:17:34.292957	1	Deadlifts
729	181	155	9	91	2017-07-29 16:17:34.29723	2017-07-29 16:17:34.29723	2	Deadlifts
730	181	155	8	91	2017-07-29 16:17:34.306089	2017-07-29 16:17:34.306089	3	Deadlifts
731	181	155	8	270	2017-07-29 16:17:34.309497	2017-07-29 16:17:34.309497	4	Deadlifts
732	181	185	6	106	2017-07-29 16:17:34.311768	2017-07-29 16:17:34.311768	1	Bench Press
733	181	185	8	121	2017-07-29 16:17:34.314151	2017-07-29 16:17:34.314151	2	Bench Press
734	181	165	8	91	2017-07-29 16:17:34.320221	2017-07-29 16:17:34.320221	3	Bench Press
735	181	165	5	241	2017-07-29 16:17:34.32443	2017-07-29 16:17:34.32443	4	Bench Press
736	182	135	8	91	2017-07-29 16:29:34.264631	2017-07-29 16:29:34.264631	1	Incline Press
737	182	135	5	91	2017-07-29 16:29:34.296524	2017-07-29 16:29:34.296524	2	Incline Press
738	182	135	5	196	2017-07-29 16:29:34.304587	2017-07-29 16:29:34.304587	3	Incline Press
739	183	0	9	61	2017-07-29 16:48:58.789086	2017-07-29 16:48:58.789086	1	Dimond pushups
740	183	0	9	91	2017-07-29 16:48:58.7941	2017-07-29 16:48:58.7941	2	Dimond pushups
741	183	0	7	61	2017-07-29 16:48:58.796195	2017-07-29 16:48:58.796195	3	Dimond pushups
742	183	0	7	112	2017-07-29 16:48:58.800432	2017-07-29 16:48:58.800432	4	Dimond pushups
743	183	50	8	91	2017-07-29 16:48:58.803722	2017-07-29 16:48:58.803722	1	Tricep Extension
744	183	45	9	91	2017-07-29 16:48:58.80662	2017-07-29 16:48:58.80662	2	Tricep Extension
745	183	0	7	91	2017-07-29 16:48:58.811553	2017-07-29 16:48:58.811553	3	Tricep Extension
\.


--
-- Name: drills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('drills_id_seq', 745, true);


--
-- Data for Name: exercise_target_muscles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY exercise_target_muscles (id, exercise_id, target_muscle_id, created_at, updated_at) FROM stdin;
1	1	2	2017-03-16 00:11:44.282234	2017-03-16 00:11:44.282234
2	1	4	2017-03-16 00:11:44.284381	2017-03-16 00:11:44.284381
3	2	7	2017-03-16 00:12:11.010381	2017-03-16 00:12:11.010381
4	2	5	2017-03-18 17:34:04.763742	2017-03-18 17:34:04.763742
5	3	6	2017-03-24 09:29:53.140407	2017-03-24 09:29:53.140407
6	4	11	2017-03-25 17:17:53.199524	2017-03-25 17:17:53.199524
7	5	8	2017-03-31 00:57:51.588084	2017-03-31 00:57:51.588084
8	6	6	2017-04-01 17:24:26.707663	2017-04-01 17:24:26.707663
9	7	6	2017-04-01 17:38:53.986871	2017-04-01 17:38:53.986871
10	8	9	2017-04-02 00:02:24.020509	2017-04-02 00:02:24.020509
11	9	8	2017-04-04 00:01:34.95796	2017-04-04 00:01:34.95796
12	10	8	2017-04-04 00:02:48.148947	2017-04-04 00:02:48.148947
13	11	10	2017-04-04 10:16:14.565324	2017-04-04 10:16:14.565324
14	12	10	2017-04-06 09:37:54.444117	2017-04-06 09:37:54.444117
15	13	9	2017-04-07 10:33:38.661589	2017-04-07 10:33:38.661589
16	14	11	2017-04-10 22:49:23.133942	2017-04-10 22:49:23.133942
17	15	9	2017-04-13 00:46:44.59767	2017-04-13 00:46:44.59767
18	16	10	2017-04-15 17:04:15.357135	2017-04-15 17:04:15.357135
19	17	8	2017-04-16 13:15:49.008429	2017-04-16 13:15:49.008429
20	18	11	2017-04-20 09:27:41.056453	2017-04-20 09:27:41.056453
21	19	2	2017-04-22 22:35:29.038897	2017-04-22 22:35:29.038897
22	19	4	2017-04-22 22:35:29.041774	2017-04-22 22:35:29.041774
23	20	3	2017-04-29 23:05:10.559033	2017-04-29 23:05:10.559033
24	21	3	2017-05-09 23:12:04.191853	2017-05-09 23:12:04.191853
25	22	7	2017-05-10 09:21:07.708567	2017-05-10 09:21:07.708567
26	23	11	2017-05-17 00:49:27.280661	2017-05-17 00:49:27.280661
27	24	11	2017-05-17 23:19:07.912794	2017-05-17 23:19:07.912794
28	25	9	2017-05-17 23:34:08.646329	2017-05-17 23:34:08.646329
29	27	7	2017-05-29 20:29:07.866483	2017-05-29 20:29:07.866483
30	28	8	2017-06-18 00:10:48.139451	2017-06-18 00:10:48.139451
31	29	2	2017-07-01 18:39:40.444146	2017-07-01 18:39:40.444146
32	29	4	2017-07-01 18:39:40.446957	2017-07-01 18:39:40.446957
33	30	11	2017-07-10 08:53:03.263498	2017-07-10 08:53:03.263498
34	31	8	2017-07-13 09:22:35.218152	2017-07-13 09:22:35.218152
35	31	7	2017-07-13 09:22:35.235912	2017-07-13 09:22:35.235912
36	32	8	2017-07-22 15:30:33.230342	2017-07-22 15:30:33.230342
\.


--
-- Name: exercise_target_muscles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('exercise_target_muscles_id_seq', 36, true);


--
-- Data for Name: exercises; Type: TABLE DATA; Schema: public; Owner: -
--

COPY exercises (id, name, description, reps, author_id, rest_period, equipment_needed, created_at, updated_at, weight, sets, rating) FROM stdin;
1	Squats	Traditional Squats	10	1	90	Barbell, plates	2017-03-16 00:11:44.276784	2017-03-16 00:11:44.276784	175	4	\N
2	Test Workout	Just a test	1	1	20	none	2017-03-16 00:12:11.007031	2017-03-16 00:12:11.007031	1	1	\N
3	Dumbell Shoulder Press	Press with dumbells	10	1	90	None	2017-03-24 09:29:53.128805	2017-03-24 09:29:53.128805	70	4	\N
4	Chinups	chinups with bar	7	1	90	none	2017-03-25 17:17:53.176651	2017-03-25 17:17:53.176651	\N	3	\N
6	Handstand Pushups	pushups with hands	5	1	145	body	2017-04-01 17:24:26.697762	2017-04-01 17:24:26.697762	0	4	\N
7	Barbell Shoulder Press	Barbell Shoulder Press	8	1	90	barbell, plates	2017-04-01 17:38:53.982459	2017-04-01 17:38:53.982459	90	3	\N
8	Bicep Curls	curls	8	1	90	none	2017-04-02 00:02:24.015617	2017-04-02 00:02:24.015617	35	4	\N
9	Pushups	Body weight pushups	7	1	90	none	2017-04-04 00:01:34.955056	2017-04-04 00:01:34.955056	150	4	\N
10	pushups	pushups	25	1	90	none	2017-04-04 00:02:48.144691	2017-04-04 00:02:48.144691	0	4	\N
11	chinups	none	8	1	90	none	2017-04-04 10:16:14.557963	2017-04-04 10:16:14.557963	0	3	\N
5	Benchpress	Bench press barbell	8	1	90	barbell	2017-03-31 00:57:51.549881	2017-04-05 21:14:05.285024	170	4	\N
12	Barbell Shrugs	Barbell Shrug	8	1	90	barbell	2017-04-06 09:37:54.42328	2017-04-06 09:37:54.42328	115	4	\N
13	bicep curl	dumbell	8	1	90	none	2017-04-07 10:33:38.651624	2017-04-07 10:33:38.651624	35	4	\N
15	Barbell Curls	Curls with Barbell	8	1	90	barbell plates	2017-04-13 00:46:44.573228	2017-04-13 00:46:44.573228	35	4	\N
16	Tricep Pushdowns	push down with cable	9	1	90	cable machine	2017-04-15 17:04:15.349202	2017-04-15 17:04:15.349202	70	4	\N
17	benchpress	press barbell	8	1	90	barbell	2017-04-16 13:15:49.000078	2017-04-16 13:15:49.000078	165	4	\N
18	chinups	chiinups	7	1	90	body	2017-04-20 09:27:41.050597	2017-04-20 09:27:41.050597	0	4	\N
19	Deadlifts with bar	deadlifts	10	1	90	barbell	2017-04-22 22:35:29.027983	2017-04-22 22:35:29.027983	115	4	\N
20	handing abbs		6	1	90		2017-04-29 23:05:10.483398	2017-04-29 23:05:10.483398	0	7	\N
21	situps	regular situps	25	1	90	none	2017-05-09 23:12:04.149063	2017-05-09 23:12:04.149063	0	4	\N
23	pullups	with bar long one	4	1	100	bar	2017-05-17 00:49:27.171297	2017-05-17 00:49:27.171297	0	10	\N
25	Higy Cable Curl	curl with cables	8	1	90	cable machine	2017-05-17 23:34:08.643285	2017-05-17 23:34:08.643285	15	4	\N
26	dips	\N	12	1	60	\N	2017-05-27 19:05:31.916895	2017-05-27 19:05:31.916895	0	4	\N
22	Tricep Pushdown	push down on machine	10	1	90	cable machine	2017-05-10 09:21:07.607367	2017-05-29 19:42:12.826755	80	4	\N
27	Dips 	tricep focused dips	7	1	90	none	2017-05-29 20:29:07.861776	2017-05-29 20:29:07.861776	0	4	\N
14	pullups	pulls with bar	5	1	110	body	2017-04-10 22:49:23.12351	2017-06-15 08:52:14.08316	0	4	\N
24	Shrugs	barbell shrugs	12	1	90	140	2017-05-17 23:19:07.764942	2017-06-16 08:59:51.020804	70	4	\N
28	Incline Press	incline benchpress	10	1	90	barbell w bench	2017-06-18 00:10:48.131397	2017-06-18 00:10:48.131397	135	3	\N
29	Forward Lunges Barbell	lunch with barbell	10	1	100	barbell	2017-07-01 18:39:40.410542	2017-07-01 18:39:40.410542	135	4	\N
30	Lat Pulldown	Lat	9	1	90	0	2017-07-10 08:53:03.255367	2017-07-10 08:53:03.255367	70	3	\N
31	Dimond pushups	tricep focus	13	1	60	none	2017-07-13 09:22:35.198737	2017-07-13 09:22:35.198737	0	4	\N
32	Decline Press	press decline	10	1	90	barbell	2017-07-22 15:30:33.215536	2017-07-22 15:30:33.215536	115	4	\N
\.


--
-- Name: exercises_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('exercises_id_seq', 32, true);


--
-- Data for Name: muscle_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY muscle_groups (id, name, created_at, updated_at) FROM stdin;
1	UpperBody	2017-03-16 00:02:46.305747	2017-03-16 00:02:46.305747
2	Core	2017-03-16 00:02:46.309663	2017-03-16 00:02:46.309663
3	LowerBody	2017-03-16 00:02:46.312609	2017-03-16 00:02:46.312609
\.


--
-- Name: muscle_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('muscle_groups_id_seq', 3, true);


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY plans (id, start_date, end_date, description, name, created_at, updated_at) FROM stdin;
\.


--
-- Name: plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('plans_id_seq', 1, false);


--
-- Data for Name: runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY runs (id, duration, type, asets, areps, aweight, arest, completed_date, created_at, updated_at, exercise_id, user_id, workout_id, run_date, oneoff_name) FROM stdin;
143	450	\N	\N	\N	\N	\N	\N	2017-06-22 22:30:25.422722	2017-06-22 22:30:35.372886	\N	1	\N	Thu 06/22/17	High Cable Curl
109	600	\N	\N	\N	\N	\N	\N	2017-05-09 09:26:41.574266	2017-05-09 09:30:10.121321	\N	1	\N	Tue 05/09/17	curls biceps
87	1041	\N	\N	\N	\N	\N	\N	2017-04-05 21:34:23.815913	2017-04-05 21:38:57.005834	\N	1	\N	Wed 04/05/17	normal and incline
110	682	\N	\N	\N	\N	\N	\N	2017-05-09 23:22:03.001211	2017-05-09 23:22:14.93753	\N	1	\N	Tue 05/09/17	pre cardio handstands
88	1123	\N	\N	\N	\N	\N	\N	2017-04-06 09:56:43.503556	2017-04-06 10:10:08.537806	\N	1	\N	Thu 04/06/17	Morning traps and triceps
111	826	\N	\N	\N	\N	\N	\N	2017-05-09 23:25:52.989173	2017-05-09 23:25:52.989173	\N	1	\N	Tue 05/09/17	 Untitled 
112	430	\N	\N	\N	\N	\N	\N	2017-05-10 09:28:38.332316	2017-05-10 09:28:55.663255	\N	1	\N	Wed 05/10/17	morning triceps
89	481	\N	\N	\N	\N	\N	\N	2017-04-07 10:41:43.523823	2017-04-07 10:41:55.19551	\N	1	\N	Fri 04/07/17	Friday Morning
113	154	\N	\N	\N	\N	\N	\N	2017-05-11 10:34:59.817305	2017-05-11 10:34:59.817305	\N	1	\N	Thu 05/11/17	 Untitled 
125	40	\N	\N	\N	\N	\N	\N	2017-05-29 20:27:57.259557	2017-05-29 20:28:18.869153	\N	1	\N	Mon 05/29/17	tricep pt 1
90	640	\N	\N	\N	\N	\N	\N	2017-04-08 20:48:04.03157	2017-04-08 20:48:39.645117	\N	1	\N	Sat 04/08/17	handstand pushups with abs during rest
114	1558	\N	\N	\N	\N	\N	\N	2017-05-17 01:15:41.329097	2017-05-17 01:16:11.020013	\N	1	\N	Tue 05/16/17	40 pullups
115	716	\N	\N	\N	\N	\N	\N	2017-05-17 23:31:59.634542	2017-05-17 23:32:10.039415	\N	1	\N	Wed 05/17/17	pre cardio shrugs
91	668	\N	\N	\N	\N	\N	\N	2017-04-10 23:01:55.958547	2017-04-10 23:02:09.368465	\N	1	\N	Mon 04/10/17	Monday back, pre cardio
71	4233	\N	\N	\N	\N	\N	\N	2017-03-24 10:41:26.665637	2017-03-24 10:41:26.665637	\N	1	\N	Fri 03/24/17	Morning workout
139	683	\N	\N	\N	\N	\N	\N	2017-06-16 09:11:20.656882	2017-06-16 09:15:17.823676	\N	1	\N	Fri 06/16/17	Shrugs
116	723	\N	\N	\N	\N	\N	\N	2017-05-17 23:32:20.169373	2017-05-17 23:32:27.00436	\N	1	\N	Wed 05/17/17	pre cardio bicep
126	32	\N	\N	\N	\N	\N	\N	2017-05-29 20:29:44.012261	2017-05-29 20:30:03.760586	\N	1	\N	Mon 05/29/17	Triceps pt2
92	1033	\N	\N	\N	\N	\N	\N	2017-04-13 01:04:03.157488	2017-04-15 17:03:17.339563	\N	1	\N	Wed 04/12/17	bicep workout
117	371	\N	\N	\N	\N	\N	\N	2017-05-17 23:40:56.174027	2017-05-17 23:41:04.352309	\N	1	\N	Wed 05/17/17	pre cardio biceps 2
118	411	\N	\N	\N	\N	\N	\N	2017-05-18 23:53:21.538972	2017-05-18 23:53:30.591983	\N	1	\N	Thu 05/18/17	pre cardio situps
93	725	\N	\N	\N	\N	\N	\N	2017-04-15 17:16:26.465669	2017-04-15 17:16:38.376412	\N	1	\N	Sat 04/15/17	precardio triceps
72	364	\N	\N	\N	\N	\N	\N	2017-03-25 17:24:12.947329	2017-03-25 17:24:50.919749	\N	1	\N	Sat 03/25/17	Quick Saturday workout
73	945	\N	\N	\N	\N	\N	\N	2017-03-31 01:14:23.237028	2017-03-31 01:25:00.020961	\N	1	\N	Fri 03/31/17	Thursday night
134	429	\N	\N	\N	\N	\N	\N	2017-06-07 10:32:10.934087	2017-06-07 10:32:29.164351	\N	1	\N	Wed 06/07/17	morning back pt 2
74	774	\N	\N	\N	\N	\N	\N	2017-04-01 17:37:40.191379	2017-04-01 17:38:12.18319	\N	1	\N	Sat 04/01/17	Shoulders sat pt1
119	1044	\N	\N	\N	\N	\N	\N	2017-05-18 23:57:50.335405	2017-05-18 23:58:17.514369	\N	1	\N	Thu 05/18/17	pre cardio(light) shoulders and abs
75	314	\N	\N	\N	\N	\N	\N	2017-04-01 17:57:23.839821	2017-04-01 17:57:45.251773	\N	1	\N	Sat 04/01/17	Shoulders Sat pt.2
94	614	\N	\N	\N	\N	\N	\N	2017-04-16 13:26:07.349575	2017-04-16 13:26:25.542548	\N	1	\N	Sun 04/16/17	Easter Sunday morning
127	1758	\N	\N	\N	\N	\N	\N	2017-06-01 00:06:23.707959	2017-06-01 00:06:50.025395	\N	1	\N	Wed 05/31/17	biceps... and pullups, pre intervals
120	4246	\N	\N	\N	\N	\N	\N	2017-05-20 22:21:54.77945	2017-05-20 22:22:09.84828	\N	1	\N	Sat 05/20/17	Full Body Sat
95	730	\N	\N	\N	\N	\N	\N	2017-04-18 09:24:02.584142	2017-04-18 09:56:47.66208	\N	1	\N	Tue 04/18/17	shoulders 2 situp sets inbetween
121	1308	\N	\N	\N	\N	\N	\N	2017-05-24 23:43:34.335331	2017-05-24 23:43:51.862341	\N	1	\N	Wed 05/24/17	Pre-cardo Biceps
76	1483	\N	\N	\N	\N	\N	\N	2017-04-02 00:27:26.051309	2017-04-02 02:45:11.37824	\N	1	\N	2017-04-01	Biceps Saturday
133	558	\N	\N	\N	\N	\N	\N	2017-06-07 10:24:44.070329	2017-06-07 10:32:41.941318	\N	1	\N	Wed 06/07/17	morning back pt 1
96	471	\N	\N	\N	\N	\N	\N	2017-04-19 01:55:38.807377	2017-04-19 01:57:23.673791	\N	1	\N	Tue 04/18/17	late night quick shoulders pt1
97	62	\N	\N	\N	\N	\N	\N	2017-04-19 01:56:52.688551	2017-04-19 01:57:35.381365	\N	1	\N	Tue 04/18/17	late night quick shoulders pt2
122	1321	\N	\N	\N	\N	\N	\N	2017-05-27 01:39:10.440383	2017-05-27 01:39:25.425179	\N	1	\N	Fri 05/26/17	shoulders
123	4642	\N	\N	\N	\N	\N	\N	2017-05-27 19:28:49.053923	2017-05-27 19:29:05.77587	\N	1	\N	Sat 05/27/17	Full body sat
78	421	\N	\N	\N	\N	\N	\N	2017-04-04 00:10:05.503506	2017-04-04 00:26:02.345649	\N	1	\N	2017-04-03	Monday Quick Workout
98	562	\N	\N	\N	\N	\N	\N	2017-04-19 11:38:54.121574	2017-04-19 11:40:42.690734	\N	1	\N	Wed 04/19/17	wed morning legs
129	2000	\N	\N	\N	\N	\N	\N	2017-06-01 04:00:00	2017-06-03 12:40:23.779027	\N	1	\N	Thu 06/01/17	shoulders
99	649	\N	\N	\N	\N	\N	\N	2017-04-19 11:40:25.418634	2017-04-19 11:41:04.667145	\N	1	\N	Wed 04/19/17	wed morning biceps
86	48	\N	\N	\N	\N	\N	\N	2017-04-04 10:23:38.329474	2017-04-04 10:23:52.004712	\N	1	\N	Tue 04/04/17	chinups one last set
85	360	\N	\N	\N	\N	\N	\N	2017-04-04 10:22:20.863646	2017-04-04 10:24:07.281185	\N	1	\N	Tue 04/04/17	Morning Chinups
135	3403	\N	\N	\N	\N	\N	\N	2017-06-14 00:55:43.87241	2017-06-14 00:56:02.611047	\N	1	\N	Tue 06/13/17	Upper chest and shoulder (no run day)
100	606	\N	\N	\N	\N	\N	\N	2017-04-20 09:39:29.341486	2017-04-20 09:44:01.94714	\N	1	\N	Thu 04/20/17	back pt.1
101	180	\N	\N	\N	\N	\N	\N	2017-04-20 09:43:35.498517	2017-04-20 09:44:22.813961	\N	1	\N	Thu 04/20/17	Back pt.2
130	1455	\N	\N	\N	\N	\N	\N	2017-06-03 15:19:45.967162	2017-06-03 15:20:03.441079	\N	1	\N	Sat 06/03/17	full body pt 1
102	2557	\N	\N	\N	\N	\N	\N	2017-04-22 23:19:55.217751	2017-04-22 23:20:14.341017	\N	1	\N	Sat 04/22/17	mini full body sat
103	425	\N	\N	\N	\N	\N	\N	2017-04-25 00:26:06.886709	2017-04-25 00:26:25.94399	\N	1	\N	Mon 04/24/17	chinup mon night
104	59	\N	\N	\N	\N	\N	\N	2017-04-25 12:57:06.489382	2017-04-25 12:57:17.097716	\N	1	\N	Tue 04/25/17	Tuesday Morning workout
131	2268	\N	\N	\N	\N	\N	\N	2017-06-03 15:58:11.796279	2017-06-03 15:58:19.513569	\N	1	\N	Sat 06/03/17	full body pt 2
105	1024	\N	\N	\N	\N	\N	\N	2017-04-28 21:14:05.807224	2017-04-28 21:14:32.99991	\N	1	\N	Fri 04/28/17	pre cardio
106	480	\N	\N	\N	\N	\N	\N	2017-04-29 23:13:27.681914	2017-04-29 23:13:45.354331	\N	1	\N	Sat 04/29/17	chest and curls
107	1173	\N	\N	\N	\N	\N	\N	2017-04-29 23:26:44.717321	2017-04-29 23:26:44.717321	\N	1	\N	Sat 04/29/17	 Untitled 
142	930	\N	\N	\N	\N	\N	\N	2017-06-22 22:22:26.846839	2017-06-22 22:30:58.983394	\N	1	\N	Thu 06/22/17	Barbell Curls
108	984	\N	\N	\N	\N	\N	\N	2017-05-02 23:26:36.160549	2017-05-02 23:26:50.749424	\N	1	\N	Tue 05/02/17	lat pre cardio
132	1153	\N	\N	\N	\N	\N	\N	2017-06-06 10:04:11.286989	2017-06-06 10:04:17.471905	\N	1	\N	Tue 06/06/17	Morning Biceps
136	1149	\N	\N	\N	\N	\N	\N	2017-06-14 10:33:47.711841	2017-06-14 10:33:59.330997	\N	1	\N	Wed 06/14/17	Morning Bicep
140	2300	\N	\N	\N	\N	\N	\N	2017-06-18 00:10:00.252863	2017-06-18 00:34:41.084655	\N	1	\N	Sat 06/17/17	full body pt 1
137	1179	\N	\N	\N	\N	\N	\N	2017-06-15 09:18:55.622161	2017-06-15 09:19:42.995967	\N	1	\N	Thu 06/15/17	pullups and lat pulldown(BACK)
138	539	\N	\N	\N	\N	\N	\N	2017-06-16 09:09:02.716893	2017-06-16 09:09:34.716257	\N	1	\N	Fri 06/16/17	dips(4 sets... last one 8 reps)
141	51	\N	\N	\N	\N	\N	\N	2017-06-18 00:36:04.468252	2017-06-18 00:36:17.920777	\N	1	\N	Sat 06/17/17	FUllbody pt2
145	1590	\N	\N	\N	\N	\N	\N	2017-06-28 20:06:31.499936	2017-06-28 20:06:37.91873	\N	1	\N	Wed 06/28/17	shoulders pre run
144	1422	\N	\N	\N	\N	\N	\N	2017-06-28 01:41:58.567702	2017-06-28 01:42:11.012153	\N	1	\N	Tue 06/27/17	Tuesday Biceps
146	457	\N	\N	\N	\N	\N	\N	2017-06-30 10:54:14.75157	2017-06-30 10:54:27.586862	\N	1	\N	Fri 06/30/17	Back pt 1 pullups
147	355	\N	\N	\N	\N	\N	\N	2017-06-30 11:04:08.032784	2017-06-30 11:04:20.360146	\N	1	\N	Fri 06/30/17	back pt 2 chinup
148	4084	\N	\N	\N	\N	\N	\N	2017-07-01 19:53:04.874785	2017-07-01 19:53:14.487063	\N	1	\N	Sat 07/01/17	Sat full body 
149	1406	\N	\N	\N	\N	\N	\N	2017-07-03 21:38:04.454896	2017-07-03 21:38:04.454896	\N	1	\N	Mon 07/03/17	 Untitled 
150	1211	\N	\N	\N	\N	\N	\N	2017-07-06 08:56:53.850544	2017-07-06 08:57:13.503172	\N	1	\N	Thu 07/06/17	morning shoulders
152	470	\N	\N	\N	\N	\N	\N	2017-07-07 08:55:13.725345	2017-07-07 08:55:39.31902	\N	1	\N	Fri 07/07/17	morning chinups
151	439	\N	\N	\N	\N	\N	\N	2017-07-07 08:47:12.188982	2017-07-07 08:55:30.737915	\N	1	\N	Fri 07/07/17	 morning pullups
153	341	\N	\N	\N	\N	\N	\N	2017-07-07 09:02:18.38767	2017-07-07 09:02:30.053403	\N	1	\N	Fri 07/07/17	morning shrugs
155	1404	\N	\N	\N	\N	\N	\N	2017-07-08 14:50:20.515219	2017-07-08 14:50:44.890769	\N	1	\N	Sat 07/08/17	full body sat pt 2
154	3632	\N	\N	\N	\N	\N	\N	2017-07-08 14:25:56.775657	2017-07-08 14:50:34.231972	\N	1	\N	Sat 07/08/17	full body sat pt 1
158	85	\N	\N	\N	\N	\N	\N	2017-07-12 00:25:05.654315	2017-07-12 00:25:31.55204	\N	1	\N	Tue 07/11/17	Night Biceps
156	578	\N	\N	\N	\N	\N	\N	2017-07-10 08:52:20.584626	2017-07-12 00:25:43.699061	\N	1	\N	Mon 07/10/17	pullups
157	355	\N	\N	\N	\N	\N	\N	2017-07-10 08:59:02.424332	2017-07-12 00:25:57.382629	\N	1	\N	Mon 07/10/17	pulldowns and shrugs
159	1313	\N	\N	\N	\N	\N	\N	2017-07-12 08:58:33.297164	2017-07-12 08:58:52.039128	\N	1	\N	Wed 07/12/17	morning shoulders
160	542	\N	\N	\N	\N	\N	\N	2017-07-13 09:19:35.589798	2017-07-13 09:19:35.589798	\N	1	\N	Thu 07/13/17	 Untitled 
161	408	\N	\N	\N	\N	\N	\N	2017-07-13 09:29:27.575744	2017-07-13 09:29:27.575744	\N	1	\N	Thu 07/13/17	 Untitled 
162	681	\N	\N	\N	\N	\N	\N	2017-07-14 09:22:53.39775	2017-07-14 09:33:10.277728	\N	1	\N	Fri 07/14/17	pullu[s
163	588	\N	\N	\N	\N	\N	\N	2017-07-14 09:33:01.383374	2017-07-14 09:33:18.494676	\N	1	\N	Fri 07/14/17	chinups
164	4320	\N	\N	\N	\N	\N	\N	2017-07-15 15:21:55.305536	2017-07-15 15:22:08.687298	\N	1	\N	Sat 07/15/17	Full Body
165	789	\N	\N	\N	\N	\N	\N	2017-07-17 08:55:43.965116	2017-07-17 09:06:16.345954	\N	1	\N	Mon 07/17/17	shoulders 1
166	495	\N	\N	\N	\N	\N	\N	2017-07-17 09:04:31.345926	2017-07-17 09:06:28.557455	\N	1	\N	Mon 07/17/17	shoulders 2
167	827	\N	\N	\N	\N	\N	\N	2017-07-18 09:02:50.734285	2017-07-18 09:02:50.734285	\N	1	\N	Tue 07/18/17	 Untitled 
168	464	\N	\N	\N	\N	\N	\N	2017-07-19 08:50:48.683458	2017-07-19 08:50:57.231308	\N	1	\N	Wed 07/19/17	Back1
169	677	\N	\N	\N	\N	\N	\N	2017-07-19 09:03:35.858783	2017-07-19 09:03:49.858038	\N	1	\N	Wed 07/19/17	Back 2
170	1009	\N	\N	\N	\N	\N	\N	2017-07-20 09:54:47.781849	2017-07-20 09:54:47.781849	\N	1	\N	Thu 07/20/17	 Untitled 
171	721	\N	\N	\N	\N	\N	\N	2017-07-22 15:03:58.922577	2017-07-22 17:57:35.011033	\N	1	\N	Sat 07/22/17	fully body pt1
172	728	\N	\N	\N	\N	\N	\N	2017-07-22 15:16:37.530078	2017-07-22 17:57:44.574185	\N	1	\N	Sat 07/22/17	full body pt 2
173	748	\N	\N	\N	\N	\N	\N	2017-07-22 15:29:49.663275	2017-07-22 17:57:57.456355	\N	1	\N	Sat 07/22/17	full body pt 3
174	125	\N	\N	\N	\N	\N	\N	2017-07-22 18:00:13.114753	2017-07-22 18:00:23.104311	\N	1	\N	Sat 07/22/17	full body pt 4
175	1400	\N	\N	\N	\N	\N	\N	2017-07-24 09:02:55.969294	2017-07-24 09:02:55.969294	\N	1	\N	Mon 07/24/17	 Untitled 
176	930	\N	\N	\N	\N	\N	\N	2017-07-26 09:00:43.178022	2017-07-26 09:00:43.178022	\N	1	\N	Wed 07/26/17	 Untitled 
177	586	\N	\N	\N	\N	\N	\N	2017-07-26 09:10:43.518979	2017-07-26 09:10:43.518979	\N	1	\N	Wed 07/26/17	 Untitled 
180	697	\N	\N	\N	\N	\N	\N	2017-07-28 09:00:40.00148	2017-07-28 09:00:47.725001	\N	1	\N	Fri 07/28/17	back pt 3
178	554	\N	\N	\N	\N	\N	\N	2017-07-28 08:46:20.707827	2017-07-28 09:00:56.466456	\N	1	\N	Fri 07/28/17	back pt1
179	7	\N	\N	\N	\N	\N	\N	2017-07-28 08:46:39.442526	2017-07-28 09:01:03.570434	\N	1	\N	Fri 07/28/17	back pt 2
181	1655	\N	\N	\N	\N	\N	\N	2017-07-29 16:17:34.239344	2017-07-29 16:18:02.889714	\N	1	\N	Sat 07/29/17	full body pt.1
182	672	\N	\N	\N	\N	\N	\N	2017-07-29 16:29:34.220915	2017-07-29 16:49:14.332096	\N	1	\N	Sat 07/29/17	full body pt 2
183	1132	\N	\N	\N	\N	\N	\N	2017-07-29 16:48:58.77522	2017-07-29 16:49:22.881035	\N	1	\N	Sat 07/29/17	full body pt 3
\.


--
-- Name: runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('runs_id_seq', 183, true);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY schema_migrations (version) FROM stdin;
20170315230108
20160604000350
20160604041126
20160604041754
20160604042140
20160604042320
20160604141625
20160604145036
20160604145448
20160604153943
20160604154237
20160605140124
20160605210428
20160606164531
20160606183503
20160606200907
20160608213956
20160608214200
20160608235742
20160610124110
20160811012746
20160811013149
20160812221752
20160812230504
20160816000116
20160817171937
20161002223157
20161007023837
20170221143054
20170223133730
20170225163636
20170315235533
20170316000107
20170316000353
20170316000519
20170318192204
\.


--
-- Data for Name: target_muscles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY target_muscles (id, name, muscle_group_id, run_id) FROM stdin;
1	Calves	1	\N
10	Traps	3	169
6	Shoulders	3	175
9	Biceps	3	177
11	Lats	3	180
2	Quads	1	181
4	Gluteus Maximus	2	181
8	Chest	3	183
7	Triceps	3	183
3	Abs	2	155
5	Obliques	2	84
\.


--
-- Name: target_muscles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('target_muscles_id_seq', 11, true);


--
-- Data for Name: timers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY timers (id, seconds, created_at, updated_at) FROM stdin;
\.


--
-- Name: timers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('timers_id_seq', 1, false);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY users (id, role, username, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, created_at, updated_at, provider, uid, latitude, longtitude) FROM stdin;
1	0	Cory Adams	corya0687@gmail.com	$2a$11$2bN7SPsoE3rW3caIAF80lenIlI.Hpmx3bYmG1CKxi2aQRuX/NH2FW	\N	\N	\N	13	2017-07-26 08:44:58.01297	2017-07-17 08:40:01.628999	::1	::1	2017-03-16 00:10:54.848004	2017-07-26 08:44:58.028032	facebook	1137908019585904	\N	\N
\.


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('users_id_seq', 1, true);


--
-- Data for Name: workout_exercises; Type: TABLE DATA; Schema: public; Owner: -
--

COPY workout_exercises (id, exercise_id, workout_id, created_at, updated_at, combined_rating) FROM stdin;
1	2	1	2017-05-10 10:33:32.793357	2017-05-10 10:33:32.793357	\N
2	16	2	2017-05-27 19:05:31.913208	2017-05-27 19:05:31.913208	\N
3	26	2	2017-05-27 19:05:31.920732	2017-05-27 19:05:31.920732	\N
\.


--
-- Name: workout_exercises_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('workout_exercises_id_seq', 3, true);


--
-- Data for Name: workout_muscle_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY workout_muscle_groups (id, workout_id, muscle_group_id, created_at, updated_at) FROM stdin;
1	1	1	2017-05-10 10:33:32.802434	2017-05-10 10:33:32.802434
2	2	1	2017-05-27 19:05:31.922782	2017-05-27 19:05:31.922782
\.


--
-- Name: workout_muscle_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('workout_muscle_groups_id_seq', 2, true);


--
-- Data for Name: workout_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY workout_plans (id, plan_id, workout_id, created_at, updated_at) FROM stdin;
\.


--
-- Name: workout_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('workout_plans_id_seq', 1, false);


--
-- Data for Name: workouts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY workouts (id, name, description, created_at, updated_at, author_id) FROM stdin;
1	sdfas	dfasdfas	2017-05-10 10:33:32.774121	2017-05-10 10:33:32.774121	1
2	triceps	dips and pushdowns	2017-05-27 19:05:31.910084	2017-05-27 19:05:31.910084	1
\.


--
-- Name: workouts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('workouts_id_seq', 2, true);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: drills drills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY drills
    ADD CONSTRAINT drills_pkey PRIMARY KEY (id);


--
-- Name: exercise_target_muscles exercise_target_muscles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY exercise_target_muscles
    ADD CONSTRAINT exercise_target_muscles_pkey PRIMARY KEY (id);


--
-- Name: exercises exercises_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY exercises
    ADD CONSTRAINT exercises_pkey PRIMARY KEY (id);


--
-- Name: muscle_groups muscle_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY muscle_groups
    ADD CONSTRAINT muscle_groups_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: runs runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY runs
    ADD CONSTRAINT runs_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: target_muscles target_muscles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY target_muscles
    ADD CONSTRAINT target_muscles_pkey PRIMARY KEY (id);


--
-- Name: timers timers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY timers
    ADD CONSTRAINT timers_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: workout_exercises workout_exercises_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY workout_exercises
    ADD CONSTRAINT workout_exercises_pkey PRIMARY KEY (id);


--
-- Name: workout_muscle_groups workout_muscle_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY workout_muscle_groups
    ADD CONSTRAINT workout_muscle_groups_pkey PRIMARY KEY (id);


--
-- Name: workout_plans workout_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY workout_plans
    ADD CONSTRAINT workout_plans_pkey PRIMARY KEY (id);


--
-- Name: workouts workouts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY workouts
    ADD CONSTRAINT workouts_pkey PRIMARY KEY (id);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_email ON users USING btree (email);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON users USING btree (reset_password_token);


--
-- PostgreSQL database dump complete
--

